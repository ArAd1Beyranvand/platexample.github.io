"""[D2][D8] Binds a PlateCanvas to a page under Pyodide: its retained SVG surface in a host element, one <input> per
slot input absolutely positioned over the viewBox, edits written through the controller (D7).

Everything browser-side goes through `document` (Pyodide's `js.document`) and `proxy` (Pyodide's
`create_proxy`), so tests pass fakes and the module imports without a browser."""
from __future__ import annotations

from ..core.theme.plate_theme import PlateTheme
from ..core.model.slot_behavior import SlotBehavior
from ..render.plate_canvas import PLATE_LAYERS
from .plate_canvas import PlateCanvas
from .svg import AssetResolver, PlatePicture, SvgLayers, css

SVG_NS = "http://www.w3.org/2000/svg"


def browser():
    """(document, create_proxy) under Pyodide."""
    import js  # noqa: PLC0415 - only exists in the browser
    from pyodide.ffi import create_proxy  # noqa: PLC0415
    return js.document, create_proxy


def browser_timing():
    """(clock, schedule) for PlateCanvas's animator: performance.now and requestAnimationFrame."""
    import js  # noqa: PLC0415
    from pyodide.ffi import create_once_callable  # noqa: PLC0415
    return js.performance.now, lambda fn: js.requestAnimationFrame(create_once_callable(lambda _t: fn()))


# [H14] The same in-place patch as ts/src/ui/plate_surface.ts `reconcile`, run natively: walking the DOM node by node
# through Pyodide's FFI every frame would cost more than the rewrite it saves.
_RECONCILE_JS = """
const scratch = document.createElementNS('http://www.w3.org/2000/svg', 'g');
const sync = (el, from) => {
  for (const a of Array.from(el.attributes)) if (!from.hasAttribute(a.name)) el.removeAttribute(a.name);
  for (const a of Array.from(from.attributes)) if (el.getAttribute(a.name) !== a.value) el.setAttribute(a.name, a.value);
};
const reconcile = (live, next) => {
  const want = Array.from(next.childNodes);
  want.forEach((n, i) => {
    const have = live.childNodes[i];
    if (!have) live.appendChild(n);
    else if (have.nodeType !== n.nodeType || have.nodeName !== n.nodeName) live.replaceChild(n, have);
    else if (n.nodeType === 1) { sync(have, n); reconcile(have, n); }
    else if (have.nodeValue !== n.nodeValue) have.nodeValue = n.nodeValue;
  });
  while (live.childNodes.length > want.length) live.removeChild(live.lastChild);
};
return (live, markup) => { scratch.innerHTML = markup; reconcile(live, scratch); };
"""


def browser_patch():
    """(live element, markup) -> None under Pyodide: patches the layer in place, keeping every node whose tag and
    position agree, so a fading image is never fetched or decoded again."""
    import js  # noqa: PLC0415
    return js.Function.new(_RECONCILE_JS)()


def _write(el, markup: str) -> None:
    el.innerHTML = markup


def canvas_measurer(document):
    """[H12] A text measurer over a 2D canvas context, for plates.render.text_measure."""
    ctx = document.createElement("canvas").getContext("2d")

    def measure(text: str, s: dict) -> float:
        # Not every caller's style names a family (plate_canvas's fitted-run style does not).
        family = s.get("fontFamily", "sans-serif").rsplit("/", 1)[-1]
        ctx.font = f'{s.get("fontWeight", 400)} {s["fontSize"]}px "{family}", sans-serif'
        return ctx.measureText(text).width + s.get("letterSpacing", 0) * len(text)
    return measure


class PlateSurface:
    """[D1][H14] A plate's retained SVG in the page: one `<svg>` holding a `<g>` per layer, created once. Each
    `paint` touches only the layers whose markup changed (see SvgLayers), so typing never rebuilds the frame or the
    artwork. `patch` writes a layer: in the browser `browser_patch()`, which patches it in place so a part fading
    in keeps its nodes and the flag and decal images are fetched and decoded once per spec; by default innerHTML."""

    def __init__(self, document, id_prefix: str = "", resolve_asset: AssetResolver | None = None, patch=None):
        self._layers = SvgLayers(id_prefix, resolve_asset)
        self._patch = patch or _write
        self.element = document.createElementNS(SVG_NS, "svg")
        self.element.setAttribute("style", "width:100%;height:auto;display:block")
        self.groups = {}
        for name in PLATE_LAYERS:
            g = document.createElementNS(SVG_NS, "g")
            g.setAttribute("data-layer", name)
            self.element.appendChild(g)
            self.groups[name] = g

    def paint(self, p: PlatePicture) -> list[str]:
        """Paints `p`; returns the layers it had to rewrite."""
        delta = self._layers.diff(p)
        if delta.view_box:
            self.element.setAttribute("viewBox", delta.view_box)
        for name, markup in delta.layers:
            self._patch(self.groups[name], markup)
        return [name for name, _ in delta.layers]


class DomPlate:
    """Mounts `canvas` into `host`. Sizes are percentages of the viewBox, so the host's CSS width
    alone scales the plate; nothing is measured from layout."""

    def __init__(self, host, canvas: PlateCanvas, document=None, proxy=None,
                 resolve_asset: AssetResolver | None = None, patch=None):
        if document is None:
            document, proxy = browser()
            patch = patch or browser_patch()
        self.host, self.canvas, self.resolve_asset = host, canvas, resolve_asset
        self.host.style.position = "relative"
        self.surface = PlateSurface(document, canvas.id, resolve_asset, patch)
        self.host.appendChild(self.surface.element)
        spec = canvas.spec
        self.inputs = {}
        for s in canvas.slot_inputs():
            e = document.createElement("input")
            st = e.style
            st.position, st.border, st.background, st.textAlign, st.padding = "absolute", "0", "transparent", "center", "0"
            st.left = f"{100 * s.box.left / spec.canvas_width}%"
            st.top = f"{100 * s.box.top / spec.canvas_height}%"
            st.width = f"{100 * s.box.width / spec.canvas_width}%"
            st.height = f"{100 * s.box.height / spec.canvas_height}%"
            st.fontSize = f"{72 * s.box.height / spec.canvas_width}cqw"
            st.fontWeight = "700"
            slot = spec.slots[s.index]
            theme = canvas.theme or PlateTheme.standard()
            # Transparent text: the glyphs, placeholder and underline are painted under it, in the slot's script.
            st.color, st.caretColor, st.outline = "transparent", css(theme.active_color), "none"
            e.className = "plate-slot"
            e.maxLength = slot.length
            if s.behavior in (SlotBehavior.KEYPAD_FIRST_FIELD, SlotBehavior.EXTERNAL_FIELD):
                e.inputMode = "none"  # [D8] the keypad types; the system keyboard stays down
            self._listen(e, s.index, proxy)
            self.host.appendChild(e)
            self.inputs[s.index] = e
        self.host.style.containerType = "inline-size"
        canvas.on_render = self.paint
        self.paint(canvas.picture())

    def _listen(self, e, index: int, proxy) -> None:
        def edited(_event=None) -> None:
            if not self.canvas.controller.set_at(index, e.value or None):
                self._sync()
        self._proxy = getattr(self, "_proxy", [])
        self._proxy.append(proxy(edited) if proxy else edited)
        e.addEventListener("input", self._proxy[-1])

    def _sync(self) -> None:
        values = self.canvas.controller.values
        for i, e in self.inputs.items():
            v = values[i] or ""
            if e.value != v:
                e.value = v

    def paint(self, p: PlatePicture) -> None:
        self.surface.paint(p)
        self._sync()

    def dispose(self) -> None:
        self.canvas.dispose()
        for p in getattr(self, "_proxy", []):
            if hasattr(p, "destroy"):
                p.destroy()
        self.host.innerHTML = ""
