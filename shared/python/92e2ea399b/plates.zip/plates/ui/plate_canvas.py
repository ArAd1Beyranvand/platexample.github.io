"""[D1][D7] The headless half of the browser plate (ts/src/ui/plate_canvas.ts): core state in, a layered picture
out. Painting is a PlateSurface (plates.ui.dom); native inputs go at slot_inputs()."""
from __future__ import annotations

import itertools
from typing import Callable, Generic, NamedTuple, TypeVar

from ..core.input.plate_controller import PlateController
from ..core.model.plate_box import Rect
from ..core.model.plate_country import PlateCountry
from ..core.model.plate_input_source import PlateInputSource
from ..core.model.slot_behavior import PlateMode, SlotBehavior, resolve_slot_behavior
from ..core.theme.plate_theme import PlateTheme
from ..core.input.observable import Observable
from ..core.timing.plate_animation import PlateAnimationController, PlatePartCue, PlatePartId, PlatePartPhase, all_of
from ..core.timing.plate_part_animator import PlatePartFrame, part_timeline
from ..core.timing.tween import Size, Tween, lerp_size
from ..render.plate_canvas import lerp_theme, plate_theme, render_layers, settled_frames
from ..render.plate_frame import Frames
from ..render.plate_glyph_run import GlyphRun
from ..render.plate_text_row import StaggeredText
from ..render.text_measure import measure_text
from .svg import AssetResolver, PlatePicture, picture_svg


T = TypeVar("T")
Clock = Callable[[], float]
Schedule = Callable[[Callable[[], None]], None]


class PartClock:
    """[H11] The animation driver: stamps each part's cue with the time it arrives and turns (cue, elapsed) into
    frames through the core timing model. Read at a frame time; it holds no schedule.

    Like Flutter's part widgets, each part listens to its own cue (`track`): a cue's clock starts when it arrives,
    not when the part is first painted (a flag under a hidden panel keeps its place in the stagger), and every
    arrival calls `on_cue`, so a `come_in_all` wakes the canvas that paints those parts."""

    def __init__(self, animation: PlateAnimationController, clock: Clock, on_cue: Callable[[], None] | None = None):
        self.animation, self.clock, self.on_cue = animation, clock, on_cue
        self._started: dict[PlatePartId, tuple[PlatePartCue, float]] = {}
        self._watched: dict[PlatePartId, Callable[[], None]] = {}

    def track(self, ids) -> None:
        """Listens to the cues of `ids`, stamping each new cue with the time it arrives."""
        for id in ids:
            if id in self._watched:
                continue
            cues = self.animation.cue_of(id)

            def arrived(*_, id=id, cues=cues) -> None:
                self._started[id] = (cues.value, self.clock())
                if self.on_cue:
                    self.on_cue()
            self._watched[id] = cues.subscribe(arrived)

    def _progress(self, id: PlatePartId, cue: PlatePartCue, at: float, now: float) -> float:
        if cue.phase is PlatePartPhase.SETTLED or cue.instant:
            return 1.0
        motion = self.animation.style.motion_for(id)
        return part_timeline(motion, cue).progress(motion, now - at)

    def frames(self, now: float) -> Frames:
        """Every part's frame at `now`; a cue not seen arriving starts at `now`."""
        def frame(id: PlatePartId) -> PlatePartFrame:
            self.track((id,))
            cue = self.animation.cue_of(id).value
            seen = self._started.get(id)
            if seen is None or seen[0] is not cue:
                seen = self._started[id] = (cue, now)
            return PlatePartFrame(cue.phase, self._progress(id, cue, seen[1], now), self.animation.style.motion_for(id))
        return frame

    def running(self, now: float) -> bool:
        """True while some part seen so far is still moving at `now`."""
        return any(self._progress(id, cue, at, now) < 1 for id, (cue, at) in self._started.items())

    def dispose(self) -> None:
        for id, fn in self._watched.items():
            self.animation.cue_of(id).unsubscribe(fn)
        self._watched.clear()


_LIVERY = ("plate_background", "plate_border", "ink", "divider_color", "active_color", "inactive_color")
LIVERY_MS = 350  # [H15] a livery change cross-fades this long when the spec resolves its theme from the values


class SlotInput(NamedTuple):
    """Where the UI places a native input over the painted plate [D2]. `box` is in spec units."""

    index: int
    behavior: SlotBehavior
    box: Rect
    font_size: float = 0
    letter_spacing: float = 0


def fitted_style(slot, theme: PlateTheme) -> tuple[float, float]:
    """[H12] (font size, letter spacing) shrunk so the widest full-length run fits the slot."""
    base = theme.glyph_style(slot.box.rect.height, slot.color or theme.ink, slot.spacing)
    a = slot.alphabet
    style = {"fontSize": base.pixel_size, "letterSpacing": slot.spacing}
    widest = max((measure_text(a.render(c) * slot.length, style) for c in a.characters), default=0)
    available = slot.box.rect.width - slot.spacing - 4
    if widest <= available or widest == 0:
        return base.pixel_size, slot.spacing
    k = available / widest
    return base.pixel_size * k, slot.spacing * k


_uids = itertools.count()


class PlateCanvas:
    """[D1][D7] Core state in, a layered picture out (`picture`). A host controller is adopted and never disposed.

    It owns the plate's canvas-level motion (the livery fade and the box resize as Tweens, a resolved label's
    stagger, the part cues through a PartClock) and reads them all at one frame time. With a `clock` and a
    `schedule` (performance.now and requestAnimationFrame in the browser) it animates: `on_render` gets a picture
    after each change and every frame while something moves. Without them it paints settled."""

    def __init__(self, controller: PlateController, theme: PlateTheme | None = None,
                 country: PlateCountry | None = None, mode: PlateMode = PlateMode.INPUT,
                 input_source: PlateInputSource = PlateInputSource.HARDWARE_KEYBOARD,
                 frames: Frames | None = None, on_render: Callable[["PlatePicture"], None] | None = None,
                 animation: PlateAnimationController | None = None, clock: Clock | None = None,
                 schedule: Schedule | None = None, active_index: int | None = None,
                 view_size: Callable[[], tuple[float, float]] | None = None):
        self.controller, self.theme, self.country = controller, theme, country
        self.id = f"pc{next(_uids)}-"  # prefixes this canvas's SVG ids, so several can share a page
        self.mode, self.input_source, self.active_index, self.on_render = mode, input_source, active_index, on_render
        self.clock, self.schedule = clock, schedule
        self._fixed_frames = frames
        # A leaving ghost: the box to draw into, owned by the plate that replaces it; its frame stretches to it.
        self.view_size = view_size
        self._livery: Tween[PlateTheme] | None = None
        self._box: Tween[Size] | None = None
        self._labels: dict[int, StaggeredText] = {}
        self._runs: dict[str, GlyphRun] = {}
        self._ticking = False
        self.part_clock = None
        if animation is not None and self.animates:
            self.part_clock = PartClock(animation, clock, self.invalidate)
            self.part_clock.track(all_of(controller.spec))
            animation.subscribe(self.invalidate)
        controller.subscribe(self.invalidate)
        controller.rejection.subscribe(self.invalidate)
        controller.hints.subscribe(self.invalidate)

    @property
    def animates(self) -> bool:
        return bool(self.clock and self.schedule)

    @property
    def spec(self):
        return self.controller.spec

    def _now(self) -> float:
        return self.clock() if self.clock else 0.0

    @property
    def frames(self) -> Frames:
        """The part frames now: fixed ones, the part clock's, or every part settled."""
        if self._fixed_frames:
            return self._fixed_frames
        return self.part_clock.frames(self._now()) if self.part_clock else settled_frames()

    def update(self, **fields) -> None:
        """Replaces theme, country, mode, input_source or active_index; repaints."""
        for k, v in fields.items():
            if k not in ("theme", "country", "mode", "input_source", "active_index"):
                raise TypeError(f"PlateCanvas.update() got an unexpected field {k!r}")
            setattr(self, k, v)
        self.invalidate()

    def morph_from(self, start: PlateTheme, ms: float, size: tuple[float, float] | None = None) -> None:
        """The face starts as `start` and fades to its own colours over `ms`, from now; call before the first
        render. With `size` the box also grows or shrinks from it to the spec's size over the same `ms` (ease
        in-out), the face laid out at the size it has at each frame."""
        if not self.animates:
            return
        now = self._now()
        self._livery = Tween(start, self._target_theme(), now, ms, lerp_theme)
        self._box = Tween(size, self._spec_size(), now, ms, lerp_size) if size and ms > 0 else None

    def _spec_size(self) -> Size:
        return self.spec.canvas_width, self.spec.canvas_height

    def size(self, now: float | None = None) -> Size:
        """The box the plate is drawn into at `now`: the spec's size, or the tween toward it."""
        if self.view_size:
            return self.view_size()
        now = self._now() if now is None else now
        return self._box.value_at(now) if self._box and self._box.running(now) else self._spec_size()

    def _target_theme(self) -> PlateTheme:
        return plate_theme(self.spec, self.theme, self.controller.values)

    def _theme(self, now: float) -> PlateTheme:
        """[H15] The resolved theme at `now`: a change of livery fades from where the last one had got to."""
        target = self._target_theme()
        if not self.animates:
            return target
        tw = self._livery
        if tw is None:
            self._livery = Tween.settled(target, lerp_theme)
        elif any(getattr(tw.end, k) != getattr(target, k) for k in _LIVERY):
            self._livery = tw.retarget(target, now, LIVERY_MS if self.spec.resolve_theme else 0)
        else:  # same colours, other fields (ratios, alert): follow them without restarting the fade
            self._livery = tw.follow(target)
        return self._livery.value_at(now)

    def _label_text(self, i: int, value: str, now: float) -> tuple[str, list[float] | None]:
        if not self.animates:
            return value, None
        return self._labels.setdefault(i, StaggeredText(value)).frame(value, now)

    def picture(self, now: float | None = None) -> PlatePicture:
        """The plate at one frame time: every motion read at `now`."""
        now = self._now() if now is None else now
        c = self.controller
        if self.part_clock:
            self.part_clock.track(all_of(c.spec))
        size = self.size(now)
        frames = self._fixed_frames or (self.part_clock.frames(now) if self.part_clock else None)
        layers = render_layers(c.spec, c.values, self.theme, self.country, frames, self.mode, self.input_source,
                               c.is_completed, c.rejection.value, hint_at=c.hint_at, active_index=self.active_index,
                               resolved_theme=self._theme(now), label_text=lambda i, v: self._label_text(i, v, now),
                               size=size, frame_size=self._spec_size() if self.view_size else None,
                               glyphs=None if self._fixed_frames or not self.animates else
                               lambda run, units: self._runs.setdefault(run, GlyphRun()).frame(units, now))
        return PlatePicture(size, layers)

    def display_list(self, now: float | None = None) -> list[dict]:
        """The picture as one display list, bottom layer first."""
        return self.picture(now).layers.flat()

    def animating(self, now: float | None = None) -> bool:
        """True while something still moves at `now`: a part, the livery, the box, a label. A ghost moves until
        it is dropped."""
        if not self.animates:
            return False
        now = self._now() if now is None else now
        return bool(self.view_size or (self.part_clock and self.part_clock.running(now))
                    or (self._livery and self._livery.running(now)) or (self._box and self._box.running(now))
                    or any(t.running for t in self._labels.values()) or any(g.running for g in self._runs.values()))

    def slot_inputs(self) -> list[SlotInput]:
        """In input mode, the slots the display list leaves for native inputs."""
        if self.mode is not PlateMode.INPUT:
            return []
        out = []
        for i, s in enumerate(self.spec.slots):
            b = resolve_slot_behavior(self.mode, s.alphabet.input, self.input_source)
            if b is not SlotBehavior.GLYPH:
                out.append(SlotInput(i, b, s.box.rect, *fitted_style(s, self.theme or PlateTheme.standard())))
        return out

    def svg(self, resolve_asset: AssetResolver | None = None) -> str:
        """A one-shot standalone SVG of the plate now; a live page paints through a PlateSurface instead."""
        return picture_svg(self.picture(), resolve_asset, self.id)

    def invalidate(self, *_) -> None:
        """Renders now and, while anything moves, once per scheduled frame after."""
        if not self.on_render:
            return
        now = self._now()
        self.on_render(self.picture(now))
        if not self._ticking and self.animating(now):
            self._ticking = True
            self.schedule(self._tick)

    def _tick(self) -> None:
        self._ticking = False
        self.invalidate()

    def dispose(self) -> None:
        self.on_render = None
        self.controller.unsubscribe(self.invalidate)
        self.controller.rejection.unsubscribe(self.invalidate)
        self.controller.hints.unsubscribe(self.invalidate)
        if self.part_clock:
            self.part_clock.animation.unsubscribe(self.invalidate)
            self.part_clock.dispose()


class PlateView(PlateCanvas):
    """[D1] The same canvas, editing off."""

    def __init__(self, controller: PlateController, theme: PlateTheme | None = None,
                 country: PlateCountry | None = None, frames: Frames | None = None, on_render=None):
        super().__init__(controller, theme, country, PlateMode.DISPLAY, frames=frames, on_render=on_render)


class PlateTextView:
    """The plate as text, or `empty_plate` while nothing is typed."""

    def __init__(self, controller: PlateController, empty_plate: str = ""):
        self.controller, self.empty_plate = controller, empty_plate

    def text(self) -> str:
        return self.empty_plate if self.controller.is_empty else self.controller.text()


class PlateSelector(Generic[T]):
    """[D7] `selector(controller)` as an observable that notifies only when the result changes."""

    def __init__(self, controller: PlateController, selector: Callable[[PlateController], T]):
        self.controller, self.selector = controller, selector
        self.value = Observable(selector(controller))
        controller.subscribe(self._changed)

    def _changed(self, *_) -> None:
        self.value.value = self.selector(self.controller)

    def dispose(self) -> None:
        self.controller.unsubscribe(self._changed)
