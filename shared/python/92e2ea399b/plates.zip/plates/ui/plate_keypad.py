"""[D8] The soft keypad: a headless model (`PlateKeypad`) driven by an injected clock and timers, and
`DomKeypad`, which binds it to buttons under the plate (plate_keypad/lib/src/plate_keypad.dart)."""
from __future__ import annotations

from typing import Callable

from ..core.input.observable import Observable
from ..core.model.plate_alphabet import PlateAlphabet
from ..render.plate_keypad import (
    DIGIT_LABELS, KEY_STAGGER, KEYPAD_CSS, KEYPAD_SLIDE, NO_LETTERS, ROWS, SWAP_AT, PlateKeypadTheme,
    grid_for, grid_height, height_at, is_highlight, key_enabled, key_height, key_report, keypad_vars,
    entrance, key_text, reveal,
)
from .svg import css

Clock = Callable[[], float]
Schedule = Callable[[Callable[[], None]], None]
SetTimeout = Callable[[Callable[[], None], float], object]
ClearTimeout = Callable[[object], None]


class PlateKey:
    """One key: the enabled state it shows trails the real one by the stagger (H14)."""

    def __init__(self, pad: PlateKeypad, label: str, index: int, count: int, digits, display):
        self.pad, self.label, self.index, self.count = pad, label, index, count
        self.digits, self.display = digits, display
        self.report, self.text = key_report(label, digits), key_text(label, display)
        self.shown = bool(label) and self.enabled
        self._turn = None

    @property
    def enabled(self) -> bool:
        return key_enabled(self.report, self.pad.digit_alphabet if self.digits else self.pad.letter_alphabet,
                           self.pad.active_alphabet)

    @property
    def highlighted(self) -> bool:
        return is_highlight(self.pad.highlight.value, self.label, self.digits)

    def refresh(self) -> None:
        """The enabled set may have changed: turn after the stagger, grey keys last-to-first."""
        if not self.label:
            return
        enabled = self.enabled
        if enabled == self.shown:
            self._cancel()
            return
        if self._turn is not None:
            return
        slot = self.count + self.index if enabled else self.count - 1 - self.index
        self._turn = self.pad.set_timeout(self._turned, KEY_STAGGER * slot)

    def _turned(self) -> None:
        self._turn = None
        self.shown = self.enabled
        self.pad._changed()

    def _cancel(self) -> None:
        if self._turn is not None:
            self.pad.clear_timeout(self._turn)
            self._turn = None

    def tap(self) -> None:
        if self.enabled and self.pad.on_key:
            self.pad.on_key(self.report)

    def dispose(self) -> None:
        self._cancel()


class PlateKeypad:
    def __init__(self, digit_alphabet: PlateAlphabet, letter_alphabet: PlateAlphabet = NO_LETTERS, *,
                 active_alphabet: PlateAlphabet | None = None, theme: PlateKeypadTheme | None = None,
                 compact: bool = False, show_letters: bool = False, on_key: Callable[[str], None] | None = None,
                 highlight: Observable | None = None, clock: Clock = lambda: 0.0,
                 schedule: Schedule = lambda fn: None, set_timeout: SetTimeout | None = None,
                 clear_timeout: ClearTimeout = lambda h: None, on_change: Callable[[], None] | None = None):
        self.digit_alphabet, self.letter_alphabet, self.active_alphabet = digit_alphabet, letter_alphabet, active_alphabet
        self.theme, self.compact, self.on_key = theme, compact, on_key
        self.highlight = highlight or Observable(None)
        self._unsub = self.highlight.subscribe(self._changed)
        self.clock, self.schedule, self.on_change = clock, schedule, on_change
        self.set_timeout = set_timeout or (lambda fn, ms: fn())
        self.clear_timeout = clear_timeout
        self._from = self._to = show_letters
        self._from_height: float | None = None
        self._start: float | None = None
        self._entered: float | None = None
        self._coming = True
        self.keys: list[PlateKey] = []
        self._build(show_letters)

    @classmethod
    def numeric(cls, digits: PlateAlphabet, **kw) -> PlateKeypad:
        return cls(digits, NO_LETTERS, active_alphabet=digits, **kw)

    @property
    def t(self) -> float:
        if self._start is None:
            return 1.0
        return min(1.0, max(0.0, (self.clock() - self._start) / KEYPAD_SLIDE))

    @property
    def animating(self) -> bool:
        return self._start is not None and self.t < 1.0 or self._entering

    @property
    def _entering(self) -> bool:
        return self._entered is not None and self.clock() - self._entered < KEYPAD_SLIDE

    def hide(self) -> None:
        """Every key gone at once, waiting for enter()."""
        self._entered, self._coming = float("-inf"), False
        self._changed()

    def enter(self, coming: bool = True) -> None:
        """Staggers every key in, or out with `coming` false; out, the pad stays empty until the next call."""
        self._entered, self._coming = self.clock(), coming
        self._tick()

    def _grid_height(self, letters: bool) -> float:
        return grid_height(grid_for(self.letter_alphabet).rows if letters else len(ROWS), self.compact)

    @property
    def height(self) -> float:
        t = self.t
        return height_at(t, self._from_height if self._from_height is not None else self._grid_height(self._from),
                         self._grid_height(self._to)) if self.animating else self._grid_height(self._to)

    @property
    def letters(self) -> bool:
        return self._from if self.t < SWAP_AT else self._to

    @property
    def pad_presence(self) -> float:
        """How present the pad itself is: it fades with its keys when it comes in or goes out."""
        if self._entered is None:
            return 1.0
        p = min(1.0, max(0.0, (self.clock() - self._entered) / KEYPAD_SLIDE))
        return p if self._coming else 1.0 - p

    def reveal(self, key: PlateKey) -> float:
        v = reveal(self.t, key.index, key.count)
        if self._entered is None:
            return v
        return v * entrance(self.clock() - self._entered, key.index, key.count, self._coming)

    def _build(self, letters: bool) -> None:
        for k in self.keys:
            k.dispose()
        if letters:
            labels, digits, display = grid_for(self.letter_alphabet).cells, None, self.letter_alphabet
        else:
            labels, digits, display = DIGIT_LABELS, self.digit_alphabet, self.digit_alphabet
        self.keys = [PlateKey(self, label, i, len(labels), digits, display) for i, label in enumerate(labels)]
        self.columns = grid_for(self.letter_alphabet).columns if letters else len(ROWS[0])
        self.built_letters = letters

    def set_show_letters(self, letters: bool) -> None:
        if letters == self._to:
            return
        t = self.t
        if self.animating and t < SWAP_AT:  # the old grid is still leaving: bring it back
            self._from, self._to = self._to, self._from
            self._from_height = None
            self._start = self.clock() - (1.0 - t) * KEYPAD_SLIDE
        else:
            self._from_height = self.height if self.animating else None
            self._from, self._to = self._to, letters
            self._start = self.clock()
        self._tick()

    def set_active_alphabet(self, alphabet: PlateAlphabet | None) -> None:
        self.active_alphabet = alphabet
        for k in self.keys:
            k.refresh()

    def _tick(self) -> None:
        if self.letters != self.built_letters:
            self._build(self.letters)
        self._changed()
        if self.animating:
            self.schedule(self._tick)
        elif not (self._start is not None and self.t < 1.0):
            self._start = None

    def _changed(self) -> None:
        if self.on_change:
            self.on_change()

    def dispose(self) -> None:
        self.highlight.unsubscribe(self._unsub)
        for k in self.keys:
            k.dispose()


_BACKSPACE = ('<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M22 3H7c-.69 0-1.23.35-1.59.88'
              'L0 12l5.41 8.11c.36.53.9.89 1.59.89h15c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H7.07L2.4 12l4.66-7H22v14zm-11.59-2'
              'L14 13.41 17.59 17 19 15.59 15.41 12 19 8.41 17.59 7 14 10.59 10.41 7 9 8.41 12.59 12 9 15.59z"/></svg>')


def _flag(el, name: str, on: bool) -> None:
    if on:
        el.setAttribute(name, "")
    else:
        el.removeAttribute(name)


class DomKeypad:
    """Buttons in a grid under the plate. pointerdown is cancelled so the slot input keeps focus."""

    def __init__(self, host, pad: PlateKeypad, document=None, proxy=None):
        if document is None:
            from .dom import browser
            document, proxy = browser()
        self.host, self.pad, self.document, self.proxy = host, pad, document, proxy
        self._handlers: list = []
        self.buttons: list = []
        pad.on_change = self.paint
        self.paint()

    def _on(self, el, kind: str, fn) -> None:
        h = self.proxy(fn) if self.proxy else fn
        self._handlers.append(h)
        el.addEventListener(kind, h)

    def _rebuild(self) -> None:
        pad, doc = self.pad, self.document
        if doc.getElementById("pk-css") is None:  # the keycap stylesheet, once per document
            style = doc.createElement("style")
            style.id, style.textContent = "pk-css", KEYPAD_CSS
            doc.head.appendChild(style)
        self.host.innerHTML, self.host.className = "", "pk"
        self.host.setAttribute("style", keypad_vars(pad.theme, css) if pad.theme else "")
        st = self.host.style
        st.display, st.gridTemplateColumns, st.gap, st.padding = "grid", f"repeat({pad.columns}, 1fr)", "6px", "8px"
        st.borderRadius, st.direction = "12px", pad.letter_alphabet.direction.value if pad.built_letters else "ltr"
        self.buttons = []
        for key in pad.keys:
            b, cap = doc.createElement("button"), doc.createElement("span")
            b.type, b.className, cap.className = "button", "pk-key", "pk-cap"
            if key.label == "⌫":
                cap.innerHTML = _BACKSPACE
            else:  # [D6-font] ♿ in text presentation: plain ink, not the colour emoji
                cap.textContent = key.text.replace("♿", "♿︎")
            b.appendChild(cap)
            b.style.height = f"{key_height(pad.compact)}px"
            b.style.visibility = "visible" if key.label else "hidden"
            self._on(b, "pointerdown", lambda e, b=b, k=key: (e.preventDefault(), _flag(b, "data-down", k.enabled)))
            for up in ("pointerup", "pointerleave", "pointercancel"):
                self._on(b, up, lambda e=None, b=b: _flag(b, "data-down", False))
            self._on(b, "click", lambda e=None, k=key: k.tap())
            self.host.appendChild(b)
            self.buttons.append(b)
        self._built = (pad.built_letters, id(pad.keys))

    def paint(self) -> None:
        pad = self.pad
        if getattr(self, "_built", None) != (pad.built_letters, id(pad.keys)):
            self._rebuild()
        self.host.style.opacity = str(pad.pad_presence)
        for key, b in zip(pad.keys, self.buttons):
            v = pad.reveal(key)
            b.style.opacity = str(v)
            b.style.transform = f"scale({0.6 + 0.4 * v})" if v < 1 else ""
            b.disabled = not key.shown
            _flag(b, "data-flash", key.highlighted)

    def dispose(self) -> None:
        self.pad.dispose()
        for h in self._handlers:
            if hasattr(h, "destroy"):
                h.destroy()
        self.host.innerHTML = ""
