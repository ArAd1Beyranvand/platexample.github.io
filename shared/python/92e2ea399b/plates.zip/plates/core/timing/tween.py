"""[H15] A value moving between two others over time: the one shape every canvas-level motion takes."""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Callable, Generic, TypeVar

from .plate_animation import CURVES

T = TypeVar("T")
Size = tuple[float, float]


@dataclass(frozen=True)
class Tween(Generic[T]):
    """`start` to `end` over `ms` from `at`, eased by `curve`; read at a frame time, it holds no clock."""

    start: T
    end: T
    at: float
    ms: float
    lerp: Callable[[T, T, float], T]
    curve: str = "easeInOut"

    @classmethod
    def settled(cls, value: T, lerp: Callable[[T, T, float], T]) -> "Tween[T]":
        return cls(value, value, 0.0, 0.0, lerp)

    def running(self, now: float) -> bool:
        return self.ms > 0 and now - self.at < self.ms

    def value_at(self, now: float) -> T:
        if not self.running(now):
            return self.end
        return self.lerp(self.start, self.end, CURVES[self.curve].transform(max(0.0, (now - self.at) / self.ms)))

    def retarget(self, end: T, now: float, ms: float) -> "Tween[T]":
        """A tween from wherever this one is at `now` to `end`."""
        return replace(self, start=self.value_at(now), end=end, at=now, ms=ms)

    def follow(self, end: T) -> "Tween[T]":
        """The same motion, landing on `end`."""
        return replace(self, end=end)


def lerp_size(a: Size, b: Size, t: float) -> Size:
    return a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t
