"""[D1] Keypad maths without a widget: slide phases, grid shape, key reports, keycap style
(plate_keypad/lib/src/plate_keypad.dart)."""
from __future__ import annotations

import math
from dataclasses import dataclass
from functools import lru_cache
from typing import NamedTuple

from ..core.model.plate_alphabet import AlphabetInput, PlateAlphabet
from ..core.timing.plate_animation import CURVES

BACKSPACE_KEY = "BACKSPACE"
KEYPAD_SLIDE = 560
"""[H11] Duration of a digits/letters switch in ms; the phases below are fractions of it."""

OUT_END, RESIZE_START, RESIZE_END, IN_START, SWAP_AT = 0.4, 0.3, 0.7, 0.6, 0.5
KEY_GAP = 6
KEY_STAGGER = 18

ROWS = (("1", "2", "3"), ("4", "5", "6"), ("7", "8", "9"), ("", "0", "⌫"))
DIGIT_LABELS = tuple(k for row in ROWS for k in row)


@dataclass(frozen=True)
class PlateKeypadTheme:
    """[H10] ARGB ints. Without one the pad takes the page's light or dark palette from `[data-theme]`
    (KEYPAD_CSS). Keys are keycaps: a face standing on an edge, sinking into it when pressed; disabled
    keys lie flat."""

    surface: int = 0xFF0B0E14
    key_face: int = 0xFF232A36
    key_edge: int = 0xFF07090D
    key_border: int = 0x2EFFFFFF
    ink: int = 0xFFFFFFFF
    disabled_ink: int = 0x40FFFFFF
    hover: int = 0xFF2FD4CF
    highlight: int = 0xFFE8A33D
    highlight_ink: int = 0xFF05080B


NO_LETTERS = PlateAlphabet.of("keypad.noLetters", (), AlphabetInput.CHOSEN, False)


class Grid(NamedTuple):
    cells: tuple[str, ...]
    columns: int
    rows: int


@lru_cache(maxsize=None)
def grid_for(alphabet: PlateAlphabet) -> Grid:
    """A roughly square grid from the letter count, ending in backspace (blank spacers pad the row)."""
    letters = alphabet.characters
    columns = max(1, math.ceil(math.sqrt(len(letters))))
    rows = math.ceil((len(letters) + 1) / columns)
    cells = (*letters, *[""] * max(0, rows * columns - len(letters) - 1), "⌫")
    return Grid(cells, columns, rows)


def key_height(compact: bool) -> int:
    return 44 if compact else 56


def grid_height(rows: int, compact: bool) -> float:
    return rows * key_height(compact) + (rows - 1) * KEY_GAP


def height_at(t: float, from_h: float, to_h: float) -> float:
    p = CURVES["easeInOutCubic"].transform(min(1.0, max(0.0, (t - RESIZE_START) / (RESIZE_END - RESIZE_START))))
    return from_h + (to_h - from_h) * p


def reveal(t: float, index: int, count: int) -> float:
    """How present key `index` of `count` is at `t`: 1 at rest, 0 in order as the old grid leaves."""
    if t >= 1.0:
        return 1.0
    leaving = t < SWAP_AT
    a, b = (0.0, OUT_END) if leaving else (IN_START, 1.0)
    start = 0.0 if count <= 1 else index / (count - 1) * 0.5
    p = min(1.0, max(0.0, (((t - a) / (b - a) - start) / 0.5)))
    return 1.0 - CURVES["easeInCubic"].transform(p) if leaving else CURVES["easeOutCubic"].transform(p)


def entrance(elapsed: float, index: int, count: int, coming: bool) -> float:
    """How present key `index` of `count` is `elapsed` ms into the pad coming in or going out: keys stagger
    over the first half of KEYPAD_SLIDE, in reading order coming in and reversed going out."""
    at = 0.0 if count <= 1 else (index if coming else count - 1 - index) / (count - 1) * 0.5
    p = min(1.0, max(0.0, (elapsed / KEYPAD_SLIDE - at) / 0.5))
    return CURVES["easeOutCubic"].transform(p) if coming else 1.0 - CURVES["easeInCubic"].transform(p)


def key_report(label: str, digits: PlateAlphabet | None) -> str:
    """What a key reports: its label as the alphabet displays it; backspace is its own key."""
    if label == "⌫":
        return BACKSPACE_KEY
    return label if digits is None else digits.render(label)


def key_text(label: str, display: PlateAlphabet | None) -> str:
    return label if label == "⌫" or display is None else display.render(label)


def key_enabled(key: str, own: PlateAlphabet, active: PlateAlphabet | None) -> bool:
    if not key:
        return False
    return key == BACKSPACE_KEY or (active or own).accepts(key)


def is_highlight(candidate: str | None, label: str, digits: PlateAlphabet | None) -> bool:
    """[H3] Both sides fold to canonical, so '5' lights the '۵' key."""
    if candidate is None:
        return False
    key = key_report(label, digits)
    return candidate == key or (digits is not None and digits.canonical(candidate) == digits.canonical(key))


def keypad_vars(t: PlateKeypadTheme, css) -> str:
    """A theme as the custom properties KEYPAD_CSS reads; `css` formats an ARGB int."""
    return ";".join(f"--pk-{k}:{css(v)}" for k, v in (
        ("well", t.surface), ("face", t.key_face), ("edge", t.key_edge), ("rim", t.key_border), ("ink", t.ink),
        ("dim", t.disabled_ink), ("hover", t.hover), ("flash", t.highlight), ("flash-ink", t.highlight_ink)))


KEYPAD_CSS = """
.pk{--pk-well:#080b10;--pk-face:#1e2531;--pk-edge:#020305;--pk-rim:rgba(255,255,255,.2);--pk-ink:#eaf0fb;--pk-dim:rgba(234,240,251,.25);--pk-hover:#2fd4cf;--pk-flash:#2fd4cf;--pk-flash-ink:#050608;background:var(--pk-well)}
[data-theme=light] .pk{--pk-well:#e6e9ee;--pk-face:#fff;--pk-edge:#b4bbc6;--pk-rim:rgba(0,0,0,.08);--pk-ink:#0e1219;--pk-dim:rgba(14,18,25,.25);--pk-hover:#0b7c86;--pk-flash:#0b7c86;--pk-flash-ink:#fff}
.pk-key{all:unset;position:relative;cursor:pointer;-webkit-tap-highlight-color:transparent;touch-action:manipulation}
.pk-key:disabled{cursor:default}
.pk-cap{position:absolute;inset:0 0 4px;display:flex;align-items:center;justify-content:center;padding:0 3px;box-sizing:border-box;overflow:hidden;white-space:nowrap;border-radius:10px;border:1px solid var(--pk-rim);background:linear-gradient(color-mix(in srgb,var(--pk-face),#fff 9%),var(--pk-face) 45%);color:var(--pk-ink);font:600 20px system-ui,sans-serif;box-shadow:0 4px 0 var(--pk-edge);transition:transform .22s cubic-bezier(.34,1.56,.64,1),box-shadow .22s cubic-bezier(.34,1.56,.64,1),background .22s,border-color .15s,color .18s}
@media (hover:hover){.pk-key:hover .pk-cap{border-color:var(--pk-hover)}}
.pk-key[data-down] .pk-cap,.pk-key[data-flash] .pk-cap{transform:translateY(3.4px);box-shadow:0 .6px 0 var(--pk-edge);transition-duration:60ms;transition-timing-function:ease-out}
.pk-key[data-down] .pk-cap{background:color-mix(in srgb,var(--pk-face) 72%,var(--pk-hover))}
.pk-key[data-flash] .pk-cap{background:var(--pk-flash);border-color:var(--pk-flash);color:var(--pk-flash-ink)}
.pk-key:disabled .pk-cap{transform:translateY(4px);box-shadow:none;background:transparent;border-color:transparent;color:var(--pk-dim);transition-duration:.18s}
"""
"""The keycap: CSS does the press, hover and grey-out motion. Down is quick, the release springs back; a key
sinks on `data-down` (a press) or `data-flash` (the host's highlight)."""
