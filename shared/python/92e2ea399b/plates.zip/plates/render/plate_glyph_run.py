from __future__ import annotations

import unicodedata
from typing import Callable, NamedTuple

from ..core.model.plate_alphabet import TextDirection
from ..core.model.plate_box import Rect
from ..core.timing.plate_animation import CURVES
from .display_list import DisplayList
from .text_measure import measure_text

GLYPH_ENTER_MS = 260
GLYPH_LEAVE_MS = 180
_EASE_OUT_CUBIC = CURVES["easeOutCubic"]


def glyph_units(text: str, direction: TextDirection) -> list[str]:
    """[H7] The units a run animates: graphemes left to right;
    a right-to-left run stays whole so it keeps its shaping."""
    if not text:
        return []
    if direction is TextDirection.RTL:
        return [text]
    out: list[str] = []
    for ch in text:
        # Marks, joiners and variation selectors extend the grapheme before them; so does whatever
        # follows ZWJ, and a consonant after a virama (an Indic conjunct, GB9c).
        if out and (unicodedata.category(ch).startswith("M") or ch in "\u200c\u200d"
                    or "\ufe00" <= ch <= "\ufe0f" or out[-1][-1] == "\u200d"
                    or unicodedata.combining(out[-1][-1]) == 9 and unicodedata.category(ch) == "Lo"):
            out[-1] += ch
        else:
            out.append(ch)
    return out


class Glyph(NamedTuple):
    """One unit of a run and how far in it is: 0 gone, 1 settled."""

    text: str
    t: float


class GlyphRun:
    """PlateGlyphRun's state: each unit grows in as it is added and shrinks out as it is removed. The units
    present at the first frame show at once. A replaced unit leaves before its successor comes in."""

    def __init__(self):
        self._glyphs: list[list] = []  # [text, t0, at, dir]
        self._started = False
        self.running = False

    def frame(self, units: list[str], now: float) -> list[Glyph]:
        def t(g):
            return min(1, g[1] + (now - g[2]) / GLYPH_ENTER_MS) if g[3] > 0 else max(0, g[1] - (now - g[2]) / GLYPH_LEAVE_MS)
        if not self._started:
            self._started = True
            self._glyphs = [[u, 1, now, 1] for u in units]
        self._glyphs = [g for g in self._glyphs if g[3] > 0 or t(g) > 0]
        live = [g for g in self._glyphs if g[3] > 0]
        kept = 0
        while kept < len(live) and kept < len(units) and live[kept][0] == units[kept]:
            kept += 1
        if kept < len(live) or kept < len(units):
            for g in live[kept:]:
                g[1:] = [t(g), now, -1]
            at = 0 if kept == 0 else next(i for i, g in enumerate(self._glyphs) if g is live[kept - 1]) + 1
            while at < len(self._glyphs) and self._glyphs[at][3] < 0:
                at += 1
            self._glyphs[at:at] = [[u, 0, now, 1] for u in units[kept:]]
        out = [Glyph(g[0], t(g)) for g in self._glyphs]
        self.running = any(g.t < 1 for g in out)
        return out


def paint_glyph_run(c: DisplayList, text: str, box: Rect, style: dict, direction: TextDirection,
                    placeholder: tuple[str, int] | None = None, caret: int | None = None,
                    glyphs: Callable[[list[str]], list[Glyph]] | None = None) -> None:
    """[H12] PlateGlyphRun settled: one text op per unit along `box` from its start edge,
    scaled down to fit and centred vertically at line height 1. A `placeholder` (text, colour) is painted
    faintly under the run, which then starts where the placeholder starts, each character on its twin. A `caret` colour paints the insertion point at the end of the typed text.
    `glyphs` animates the typed run (see GlyphRun)."""
    runs = []
    for t, st in [*([(placeholder[0], {**style, "color": placeholder[1]})] if placeholder and placeholder[0] else []),
                  (text, style)]:
        ghost = st is not style
        # The characters already typed hide their twins; a whole right-to-left run is split at that point.
        n = len(text) if direction is TextDirection.RTL else len(glyph_units(text, direction))
        units = ([u for u in (t[:n], t[n:]) if u] if ghost and direction is TextDirection.RTL else glyph_units(t, direction))
        if units:
            units = glyphs(units) if glyphs and not ghost else [Glyph(u, 1) for u in units]
            full = [measure_text(u.text, st) for u in units]
            widths = [w * _EASE_OUT_CUBIC.transform(u.t) for w, u in zip(full, units)]
            runs.append((units, widths, sum(widths), st, (1 if direction is TextDirection.RTL and n else n) if ghost else 0, full))
    if not runs and caret is None:
        return
    total = max((r[2] for r in runs), default=0)
    k = min(1, box.width / total if total else 1, box.height / style["fontSize"])
    ltr = direction is TextDirection.LTR
    c.save()
    c.translate(box.left + (box.width - total * k) / 2, box.top + (box.height - style["fontSize"] * k) / 2)
    c.scale(k)
    f = style["fontSize"]
    for units, widths, _, st, skip, full in runs:
        x = 0 if ltr else total
        for i, ((unit, t), w) in enumerate(zip(units, widths)):
            if not ltr:
                x -= w
            if i >= skip and t >= 1:
                c.text(text=unit, box=[x, 0, w, f], align="start", direction=direction.value, **st)
            elif i >= skip and t > 0:
                # _GlyphCell: rises from below and pops to size about its centre while its cell widens.
                e = _EASE_OUT_CUBIC.transform(t)
                c.layer(None, CURVES["easeOut"].transform(t))
                c.translate(x + w / 2, f / 2 + (1 - e) * f * 0.3)
                c.scale(0.6 + 0.4 * CURVES["easeOutBack"].transform(t))
                c.text(text=unit, box=[-full[i] / 2, -f / 2, full[i], f], align="start", direction=direction.value, **st)
                c.restore()
            if ltr:
                x += w
    if caret is not None:
        typed = next((r[2] for r in runs if r[3] is style), 0)
        x = typed if ltr else total - typed
        c.rect(Rect(x, f * 0.1, f * 0.05, f * 0.8), {"color": caret})
    c.restore()
