from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, NamedTuple

from ..core.model.plate_alphabet import TextDirection
from ..core.model.plate_asset import PlateDrawing
from ..core.model.plate_box import PlateBox, Rect
from ..core.model.plate_country import PlateCountry
from ..core.model.plate_input_source import PlateInputSource
from ..core.model.plate_restriction import PlateRestriction
from ..core.model.plate_spec import PlateSpec
from ..core.model.slot_behavior import PlateMode, SlotBehavior, resolve_slot_behavior
from ..core.theme.plate_theme import PlateTheme, _lerp_color
from ..core.timing.plate_animation import PlateAnimationStyle, PlatePartId, PlatePartKind, PlatePartPhase
from ..core.timing.plate_part_animator import PlatePartFrame
from .country_panel import paint_panel
from .display_list import DisplayList
from .plate_divider import paint_divider
from .plate_drawing_view import paint_drawing
from .plate_flag import asset_op
from .plate_frame import Frames, frame_geometry, paint_frame, rim_clip
from .plate_glyph_run import paint_glyph_run
from .plate_text_row import paint_text_line

_K = PlatePartKind
_COLOURS = ("plate_background", "plate_border", "ink", "divider_color", "active_color", "inactive_color")


def lerp_theme(a: PlateTheme, b: PlateTheme, t: float) -> PlateTheme:
    """[H15] _ThemeTween: the six colours the livery cross-fades; ratios and alert come from `b`."""
    return b.copy_with(**{k: _lerp_color(getattr(a, k), getattr(b, k), t) for k in _COLOURS})


def plate_theme(spec: PlateSpec, theme: PlateTheme | None, values: list[str | None]) -> PlateTheme:
    """[H4] The theme a plate paints with: the spec's overrides on `theme`, then its resolver over `values`."""
    base = theme or PlateTheme.standard()
    if spec.border_width_ratio_override is not None:
        base = base.copy_with(border_width_ratio=spec.border_width_ratio_override)
    ink = spec.ink_override
    if ink is not None:
        base = base.copy_with(ink=ink, plate_border=ink, divider_color=ink, active_color=ink)
    if spec.resolve_theme:
        base = spec.resolve_theme(base, lambda k: spec.value_of_group(k, values))
    return base


def settled_frames(style: PlateAnimationStyle | None = None) -> Frames:
    """Every part settled, as the vectors render."""
    style = style or PlateAnimationStyle()
    return lambda id: PlatePartFrame(PlatePartPhase.SETTLED, 1.0, style.motion_for(id))


def _clip_overflow(c: DisplayList, w: float, h: float, boxes: list[PlateBox]) -> None:
    """Flutter's Stack clips its children to itself only when one of them overflows it."""
    if any(b.left < 0 or b.top < 0 or b.right > w or b.bottom > h for b in boxes):
        c.clip_rect(Rect(0, 0, w, h))


def _style(g, height=1, family="Roboto", weight=700, spacing=0) -> dict:
    return {"fontSize": g.pixel_size, "height": height, "color": g.color, "fontFamily": family,
            "fontWeight": weight, "letterSpacing": spacing}


PLATE_LAYERS = ("frame", "artwork", "inputs")
"""[D1] The layers a plate paints in, bottom to top: Flutter's `_MorphingFrame`, `_PlateContent` and `_PlateInputs`.

They change at different rates, which is the point of keeping them apart. The frame (face, regions, border) changes
on a livery fade, a resize or a completion flip; the artwork (country panel, flag, bands, rules, labels, decals and
their images) only when the spec, the theme or a resolved label's wording does; the inputs (mirrors, slots, the
restriction banner) on every keystroke. A host repaints only the layers whose display list changed."""


class PlateLayers(NamedTuple):
    """One frame of a plate as its three display lists, in view units."""

    frame: list[dict]
    artwork: list[dict]
    inputs: list[dict]

    def flat(self) -> list[dict]:
        """The layers as one display list, bottom to top: what the vectors record."""
        return [*self.frame, *self.artwork, *self.inputs]


@dataclass(frozen=True)
class _Scene:
    """Everything one frame of one plate is painted from, resolved once and shared by the layer painters."""

    spec: PlateSpec
    values: list[str | None]
    theme: PlateTheme
    country: PlateCountry
    frames: Frames
    view: tuple[float, float]
    rim: object

    @property
    def w(self) -> float:
        return self.spec.canvas_width

    @property
    def h(self) -> float:
        return self.spec.canvas_height

    def shown(self, kind, i=0) -> bool:
        return not self.frames(PlatePartId(kind, i)).hidden

    def fitted(self, boxes, paint: Callable[[DisplayList], None]) -> list[dict]:
        """Records `paint` in spec units, contain-fitted to the view and held inside the rim, as its own list."""
        c = DisplayList()
        vw, vh = self.view
        k = min(vw / self.w, vh / self.h)
        c.save()
        c.translate((vw - self.w * k) / 2, (vh - self.h * k) / 2)
        c.scale(k)
        c.clip_rrect(self.rim)
        _clip_overflow(c, self.w, self.h, list(boxes))
        paint(c)
        c.restore()
        return c.ops


def _frame_layer(s: _Scene, is_completed: bool, frame_size) -> list[dict]:
    """Face, regions, dividers and border, laid out at the frame size and stretched to the view."""
    c = DisplayList()
    vw, vh = s.view
    fw, fh = frame_size or (vw, vh)
    c.save()
    c.scale(vw / fw, vh / fh)
    paint_frame(c, s.theme, fw, fh, s.spec.background, s.country.panel_color, is_completed, s.frames)
    c.restore()
    return c.ops


def _artwork_layer(s: _Scene, label_text) -> list[dict]:
    """The printed furniture: country panel, bands, rules, labels and decals."""
    spec, theme = s.spec, s.theme

    def group(k):
        return spec.value_of_group(k, s.values)

    def paint(c: DisplayList) -> None:
        if spec.panel and s.shown(_K.PANEL):
            paint_panel(c, spec.panel, s.country, theme.ink, not spec.background.paints_panel(),
                        s.shown(_K.FLAG), s.shown(_K.CAPTION))
        for i, b in enumerate(spec.bands):
            if not s.shown(_K.BAND, i):
                continue
            t, bt = b.top_corner_radius or 0, b.bottom_corner_radius or 0
            if t == 0 and bt == 0:
                c.rect(b.box.rect, {"color": b.color})
            else:
                c.rrect([b.box.left, b.box.top, b.box.width, b.box.height, t, t, t, t, bt, bt, bt, bt], {"color": b.color})
        for i, r in enumerate(spec.rules):
            c.save()
            c.translate(r.box.left, r.box.top)
            paint_divider(c, Rect(0, 0, r.box.width, r.box.height), theme.divider_color, s.frames(PlatePartId(_K.RULE, i)))
            c.restore()
        for i, l in enumerate(spec.labels):
            if not s.shown(_K.LABEL, i):
                continue
            text, alphas = l.text, None
            if l.resolve:
                resolved = l.resolve(group)
                text = l.text if resolved is None else resolved
                if label_text:
                    text, alphas = label_text(i, text)
            family = f"packages/{l.font_package}/{l.font_family}" if l.font_package else (l.font_family or "Roboto")
            g = theme.glyph_style(l.glyph_height, theme.ink if l.color is None else l.color)
            style = _style(g, 1 if l.line_height is None else l.line_height, family)
            paint_text_line(c, text, l.box.rect, style, spec.text_direction, l.rotated, alphas=alphas)
        for i, d in enumerate(spec.decals):
            if not s.shown(_K.DECAL, i):
                continue
            if isinstance(d.drawing, PlateDrawing):
                c.save()
                c.translate(d.box.left, d.box.top)
                paint_drawing(c, d.drawing, d.box.width, d.box.height, "contain")
                c.restore()
            else:
                asset_op(c, d.image, d.box.rect)

    return s.fitted([*([spec.panel.box] if spec.panel else []), *(b.box for b in spec.bands),
                     *(r.box for r in spec.rules), *(l.box for l in spec.labels), *(d.box for d in spec.decals)], paint)


def _inputs_layer(s: _Scene, mode, input_source, rejection, hint_at, active_index) -> list[dict]:
    """What the user types: mirrors, slots (glyphs, or a field's placeholder and underline), the restriction banner."""
    spec, theme, values, w, h = s.spec, s.theme, s.values, s.w, s.h

    def paint(c: DisplayList) -> None:
        for i, m in enumerate(spec.mirrors):
            v = values[m.source]
            if not s.shown(_K.MIRROR, i) or not v:
                continue
            alphabet = m.alphabet or spec.slots[m.source].alphabet
            paint_glyph_run(c, alphabet.render_all(v), m.box.rect, _style(theme.glyph_style(m.glyph_height, theme.ink)),
                            alphabet.direction)
        for i, sl in enumerate(spec.slots):
            if not s.shown(_K.SLOT, i):
                continue
            v = values[i]
            g = theme.glyph_style(sl.box.height, theme.ink if sl.color is None else sl.color, sl.spacing)
            style = _style(g, spacing=g.letter_spacing)
            # [D2] Anything but a glyph is a native input the UI layer places at the slot box; its glyphs,
            # placeholder and underline are still painted here, under the transparent field.
            field = mode is PlateMode.INPUT and input_source is not None and \
                resolve_slot_behavior(mode, sl.alphabet.input, input_source) is not SlotBehavior.GLYPH
            if not field:
                paint_glyph_run(c, sl.render(v) if v else "", sl.box.rect, style, sl.alphabet.direction)
                continue
            r, inset = sl.box.rect, sl.box.height * 0.14
            hint = (hint_at(i) if hint_at else None) or sl.alphabet.placeholder
            paint_glyph_run(c, sl.render(v) if v else "", Rect(r.left, r.top + inset, r.width, r.height - 2 * inset),
                            style, sl.alphabet.direction, (hint, theme.inactive_color))
            lit = bool(v) or active_index == i
            c.rect(Rect(r.left, r.bottom - 1, r.width, 1), {"color": theme.active_color if lit else theme.inactive_color})
        if rejection:
            bh = h * 0.42
            top = (h - bh) / 2
            c.rect(Rect(0, top, w, bh), {"color": theme.alert_color})
            style = {"fontSize": h * 0.26, "height": 1, "color": 0xFFFFFFFF, "fontFamily": "Roboto", "fontWeight": 800,
                     "letterSpacing": 0.25}
            paint_text_line(c, rejection.reason, Rect(h * 0.1, top, w - h * 0.2, bh), style, TextDirection.LTR,
                            False, "start")

    return s.fitted([*(m.box for m in spec.mirrors), *(sl.box for sl in spec.slots)], paint)


def render_layers(spec: PlateSpec, values: list[str | None], theme: PlateTheme | None = None,
                  country: PlateCountry | None = None, frames: Frames | None = None, mode: PlateMode | None = None,
                  input_source: PlateInputSource | None = None, is_completed: bool | None = None,
                  rejection: PlateRestriction | None = None, size: tuple[float, float] | None = None,
                  hint_at: Callable[[int], str | None] | None = None, active_index: int | None = None,
                  resolved_theme: PlateTheme | None = None,
                  label_text: Callable[[int, str], tuple[str, list[float] | None]] | None = None,
                  frame_size: tuple[float, float] | None = None) -> PlateLayers:
    """[D1] PlateCanvas as its three layers (see PLATE_LAYERS), in view units: the frame laid out at `frame_size`
    and stretched to `size` (by default `size` itself, so a plate resizing between specs draws its face at the size
    it has now; a leaving ghost passes its own canvas), then the artwork and the inputs, contain-fitted, each under
    the rim clip. `size` defaults to the canvas. `resolved_theme` (a tween in flight) skips `plate_theme`;
    `hint_at` and `active_index` dress the slots of input mode."""
    frames = frames or settled_frames()
    theme = resolved_theme or plate_theme(spec, theme, values)
    w, h = spec.canvas_width, spec.canvas_height
    if is_completed is None:
        is_completed = all(s.is_complete(values[i]) for i, s in enumerate(spec.slots))
    scene = _Scene(spec, values, theme, country or spec.country, frames, size or (w, h),
                   rim_clip(frame_geometry(theme, w, h, frames)))
    return PlateLayers(_frame_layer(scene, is_completed, frame_size), _artwork_layer(scene, label_text),
                       _inputs_layer(scene, mode, input_source, rejection, hint_at, active_index))


def render_plate(*args, **kwargs) -> list[dict]:
    """[D1] PlateCanvas as one display list: its layers bottom to top (see render_layers), the shape of
    ports/vectors/render."""
    return render_layers(*args, **kwargs).flat()
