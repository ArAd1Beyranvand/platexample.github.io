"""Reading a plate from free text."""
from __future__ import annotations

import unicodedata
from dataclasses import dataclass
from typing import Iterable

from ..model.plate_alphabet import AlphabetInput, split_runes
from ..model.plate_spec import PlateSlot, PlateSpec
from ..model.plate_type import PlateType
from ..validators.plate_validator import PlateValidator
from .plate_controller import PlateController


@dataclass(frozen=True)
class ParsedPlate:
    """What `parse_plate` made of a string."""

    spec: PlateSpec
    """The spec the plate ended on: the one given, or the one its `resolve_spec` names for these values."""
    values: tuple[str | None, ...]
    """One canonical value per slot; None where the text gave none."""
    text: str
    """The plate as it is printed, groups joined by a space."""
    unmatched: str
    """Letters and digits of the input that no slot took, in order; empty when everything fitted."""
    is_complete: bool
    reason: str | None
    """Why the plate is refused, from a restriction or the validator; None when neither objects."""

    @property
    def is_valid(self) -> bool:
        """Every slot filled, nothing left over, and no restriction or validator objects."""
        return self.is_complete and not self.unmatched and self.reason is None

    def __str__(self) -> str:
        return self.text


@dataclass(frozen=True)
class PlateMatch:
    """A type `match_plate` found a string to be a valid plate of."""

    type: PlateType
    plate: ParsedPlate

    def _repr_svg_(self) -> str:
        from ..ui.plate_view import render_plate_svg
        return render_plate_svg(self.type, self.plate.values)


def _is_word(rune: str) -> bool:
    return unicodedata.category(rune)[0] in "LN"


def _printed(slot: PlateSlot) -> str | None:
    """The slot's single character when its alphabet holds exactly one: printed on the plate, not typed."""
    return slot.alphabet.characters[0] if slot.length == 1 and len(slot.alphabet.characters) == 1 else None


def _after_prefix(prefix: str, runes: list[str], at: int) -> int:
    """Where reading resumes once the words of `prefix` (a group's printed lead, like `CD`) are passed; `at` if they are not next."""
    i = at
    for want in filter(_is_word, split_runes(prefix)):
        while i < len(runes) and not _is_word(runes[i]):
            i += 1
        if i >= len(runes) or runes[i].upper() != want.upper():
            return at
        i += 1
    return i


def parse_plate(plate: PlateType | PlateSpec, text: str, validator: PlateValidator | None = None) -> ParsedPlate:
    """Reads a plate as a person writes it: in storage or display form (`12ب345`, `۱۲ب۳۴۵`), in any case, with or
    without separators. `plate` is a type (judged by its own validator) or a bare spec.

    A slot shorter than its length ends at the first character it refuses, so `B X 1234` and `BX1234` both fill a
    one-to-three letter register with one letter. Two such registers of the same alphabet in a row need a separator
    between them; without one the first takes all it can.

    It never raises: text that does not fit comes back with `is_valid` false and the cause in `unmatched` or `reason`."""
    spec = plate.spec if isinstance(plate, PlateType) else plate
    if isinstance(plate, PlateType) and validator is None:
        validator = plate.validator
    runes = split_runes(unicodedata.normalize("NFC", text))
    values: list[str | None] = [None] * spec.slot_count
    # Text reads group by group, which is not always slot order (a right-to-left register printed first).
    grouped = [i for g in spec.effective_text_groups for i in g.indices]
    order = grouped + [i for i in range(spec.slot_count) if i not in grouped]
    longest: dict[str, int] = {}

    def symbol_at(slot: PlateSlot, at: int) -> int:
        """How many runes at `at` form the longest symbol a chosen slot accepts whole (Iran's `الف` is one symbol); 0 for none."""
        a = slot.alphabet
        if a.id not in longest:
            longest[a.id] = max(len(split_runes(c)) for c in (*a.characters, *a.glyphs.values()))
        for n in range(min(len(runes) - at, longest[a.id]), 0, -1):
            if a.accepts("".join(runes[at:at + n])):
                return n
        return 0

    unmatched: list[str] = []
    n = at = 0
    while at < len(runes) and n < len(order):
        index = order[n]
        slot, group = spec.slots[index], spec.group_at(index)
        if group and group.prefix and group.indices[0] == index and not values[index]:
            at = _after_prefix(group.prefix, runes, at)
        if at >= len(runes):
            break
        rune, fixed, held = runes[at], _printed(slot), values[index] or ""
        chosen = slot.alphabet.input is AlphabetInput.CHOSEN
        symbol = symbol_at(slot, at) if (fixed is not None or chosen) and not held else 0
        if fixed is not None:
            # A printed symbol may be written out or left off; a separator before it belongs to no one.
            if symbol == 0 and not _is_word(rune):
                at += 1
            else:
                at, n = at + symbol, n + 1
        elif symbol:
            values[index] = slot.canonical("".join(runes[at:at + symbol]))
            at, n = at + symbol, n + 1
        elif not chosen and slot.accepts(held + rune):
            values[index] = slot.canonical(held + rune)
            at += 1
            if slot.is_full(values[index]):
                n += 1
        elif slot.is_complete(held):
            n += 1
        else:
            if _is_word(rune):
                unmatched.append(rune)
            at += 1
    unmatched += filter(_is_word, runes[at:])

    c = PlateController(spec, values, validator=validator)
    verdict = c.validation
    return ParsedPlate(c.spec, tuple(c.values), c.text(), "".join(unmatched), c.is_completed, verdict.reason if verdict else None)


def match_plate(types: Iterable[PlateType], text: str) -> list[PlateMatch]:
    """Every type of `types` that `text` is a valid plate of, in their order: pass a country's `types` to learn which
    plate a string is. Empty when it is none of them."""
    return [PlateMatch(t, p) for t in types if (p := parse_plate(t, text)).is_valid]
