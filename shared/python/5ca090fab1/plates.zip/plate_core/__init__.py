"""Licence plates of the world: read a plate from text, validate it, draw it as SVG.

Countries are separate packages (`iran_plate`, `germany_plate`, …), each exporting one `LoadedCountry`:

    from iran_plate import iran
    from plate_core import match_plate, render_plate_svg

    match = match_plate(iran.types, "۱۲ب۳۴۵-۱۱")[0]
    svg = render_plate_svg(match.type, match.plate.values)

`plate_core.pydantic` and `plate_core.django` adapt this to those frameworks; `plate_core.ui` and
`plate_core.embed` are the interactive plate for a browser running Python (Pyodide)."""
from .countries.load import LoadedCountry, load_country
from .input.plate_controller import PlateController, PlateValuePreservation
from .input.plate_parse import ParsedPlate, PlateMatch, match_plate, parse_plate
from .model.plate_alphabet import LATIN_DIGITS, LATIN_UPPERCASE, AlphabetInput, PlateAlphabet, TextDirection
from .model.plate_country import PlateCountry
from .model.plate_restriction import PlateRestriction, PlateRestrictionError
from .model.plate_spec import PlateSlot, PlateSpec, PlateTextGroup
from .model.plate_type import PlateType
from .theme.plate_theme import PlateTheme
from .ui.plate_view import render_plate_svg
from .validators.plate_validator import (GatedPlateValidator, PlateCheck, PlateEntry, PlateValidation, PlateValidator,
                                         RuledPlateValidator, is_digits, is_digits_of_length, restriction_verdict)

__all__ = [
    "AlphabetInput", "GatedPlateValidator", "LATIN_DIGITS", "LATIN_UPPERCASE", "LoadedCountry", "ParsedPlate",
    "PlateAlphabet", "PlateCheck", "PlateController", "PlateCountry", "PlateEntry", "PlateMatch", "PlateRestriction",
    "PlateRestrictionError", "PlateSlot", "PlateSpec", "PlateTextGroup", "PlateTheme", "PlateType", "PlateValidation",
    "PlateValidator", "PlateValuePreservation", "RuledPlateValidator", "TextDirection", "installed_countries",
    "is_digits", "is_digits_of_length", "load_country", "match_plate", "parse_plate", "render_plate_svg",
    "restriction_verdict",
]


def installed_countries() -> dict[str, LoadedCountry]:
    """Every country package installed beside plate_core, by name (`iran`, `germany`): each registers itself under
    the `plate_core.countries` entry-point group. Loading one builds its specs, so this is as heavy as what is installed."""
    from importlib.metadata import entry_points
    return {e.name: e.load() for e in sorted(entry_points(group="plate_core.countries"), key=lambda e: e.name)}
