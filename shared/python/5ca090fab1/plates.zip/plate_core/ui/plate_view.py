from __future__ import annotations

from typing import Sequence

from ..input.plate_controller import PlateController
from ..model.plate_country import PlateCountry
from ..model.plate_spec import PlateSpec
from ..model.plate_type import PlateType
from ..theme.plate_theme import PlateTheme
from .plate_canvas import PlateView
from .svg import AssetResolver


def render_plate_svg(plate: PlateType | PlateSpec, values: Sequence[str | None] | None = None, *,
                     theme: PlateTheme | None = None, country: PlateCountry | None = None,
                     resolve_asset: AssetResolver | None = None) -> str:
    """A read-only plate as a standalone `<svg>` string. A type is painted in its own livery and holds its sample
    when `values` is omitted; a bare spec takes `theme` and `country`.

    Files a plate paints (a seal, a sticker) are referenced as `packages/<package>/<path>` unless `resolve_asset`
    maps `(package, path)` to another URL."""
    if isinstance(plate, PlateType):
        values = plate.sample_values if values is None else values
        theme, country, plate = theme or plate.theme, country or plate.country, plate.spec
    view = PlateView(PlateController(plate, values), theme, country)
    try:
        return view.svg(resolve_asset)
    finally:
        view.dispose()
