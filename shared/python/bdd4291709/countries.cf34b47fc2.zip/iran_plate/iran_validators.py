from plate_core import PlateCheck, RuledPlateValidator


class IranTemporaryValidator(RuledPlateValidator):
    gate_group = "month"
    checks = (
        PlateCheck("year", r"[0-9]{2}", "The year is 2 digits, 00 to 99."),
        PlateCheck("month", r"0?[1-9]|1[0-2]", "The month is 1 to 12."),
    )
