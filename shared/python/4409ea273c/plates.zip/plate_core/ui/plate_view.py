from __future__ import annotations

import base64
import mimetypes
from importlib import resources
from typing import Sequence

from ..input.plate_controller import PlateController
from ..model.plate_country import PlateCountry
from ..model.plate_spec import PlateSpec
from ..model.plate_type import PlateType
from ..theme.plate_theme import PlateTheme
from .plate_canvas import PlateView
from .svg import AssetResolver


def render_plate_svg(plate: PlateType | PlateSpec, values: Sequence[str | None] | None = None, *,
                     theme: PlateTheme | None = None, country: PlateCountry | None = None,
                     resolve_asset: AssetResolver | None = None) -> str:
    """A read-only plate as a standalone `<svg>` string. A type is painted in its own livery and holds its sample
    when `values` is omitted; a bare spec takes `theme` and `country`.

    Files a plate paints (a seal, a sticker) are referenced as `packages/<package>/<path>` unless `resolve_asset`
    maps `(package, path)` to another URL; `inline_asset` embeds them instead."""
    if isinstance(plate, PlateType):
        values = plate.sample_values if values is None else values
        theme, country, plate = theme or plate.theme, country or plate.country, plate.spec
    view = PlateView(PlateController(plate, values), theme, country)
    try:
        return view.svg(resolve_asset)
    finally:
        view.dispose()


def inline_asset(package: str, path: str) -> str:
    """A `resolve_asset` that embeds the file shipped in the installed country package as a `data:` URI, so the SVG
    stands alone (an email, a PDF, a notebook). A file that is not installed keeps its `packages/…` reference."""
    try:
        data = resources.files(package).joinpath(path).read_bytes()
    except (ModuleNotFoundError, FileNotFoundError):
        return f"packages/{package}/{path}"
    return f"data:{mimetypes.guess_type(path)[0] or 'application/octet-stream'};base64,{base64.b64encode(data).decode()}"
