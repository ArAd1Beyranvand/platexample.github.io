"""What the framework adapters share: a plate read from text or a ValueError saying why not."""
from __future__ import annotations

from importlib import import_module
from typing import Iterable

from .input.plate_parse import PlateMatch, match_plate, parse_plate
from .model.plate_type import PlateType


def types_of(country: str, ids: Iterable[str] = ()) -> tuple[PlateType, ...]:
    """The types of an installed country by name (`"iran"` is `iran_plate.iran`), narrowed to `ids` when given."""
    ids = tuple(ids)
    types = getattr(import_module(f"{country}_plate"), country).types
    found = tuple(t for t in types if not ids or t.id in ids)
    if missing := set(ids) - {t.id for t in found}:
        raise LookupError(f"{country}_plate has no plate type {sorted(missing)}")
    return found


def read(types: Iterable[PlateType], text: str) -> PlateMatch:
    """The first type `text` is a valid plate of. With one type to try, the error carries its own reason."""
    types = tuple(types)
    if found := match_plate(types, text):
        return found[0]
    reason = parse_plate(types[0], text).reason if len(types) == 1 else None
    raise ValueError(reason or "Not a valid licence plate.")
