from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .plate_country import PlateCountry
from .plate_spec import PlateSpec

if TYPE_CHECKING:
    from ..theme.plate_theme import PlateTheme
    from ..validators.plate_validator import PlateValidator


@dataclass(frozen=True, eq=False)
class PlateType:
    """One plate a country issues, ready to show, render or parse: a spec with the theme, panel and validator it goes with."""

    id: str
    label: str
    """English name for a picker, e.g. `Civil`."""
    spec: PlateSpec
    sample_values: tuple[str | None, ...]
    """A plausible plate, one value per slot: draw it as a hint, or use it in tests."""
    theme: PlateTheme | None = None
    country: PlateCountry | None = None
    """Set when this type is printed with another panel than the spec's own."""
    validator: PlateValidator | None = None
    note: str | None = None

    def __repr__(self) -> str:
        return f"PlateType({self.id!r})"

    def _repr_svg_(self) -> str:
        from ..ui.plate_view import inline_asset, render_plate_svg
        return render_plate_svg(self, resolve_asset=inline_asset)
