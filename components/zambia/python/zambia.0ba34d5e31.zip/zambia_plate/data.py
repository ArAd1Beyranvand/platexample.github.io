"""Generated from the shared data of zambia_plate; do not edit."""
from plate_core import load_country
from .zambia_validators import ZambiaValidator

zambia = load_country(r'''{"package":"zambia_plate","alphabets":{"latin.digits":["latin.digits",[["0","9"]],"typed",true],"latin.upper":["latin.upper",[["A","Z"]]]},"countries":{"ZambiaCountry.zambia":["zm",4293718263,4289012262,1.75]},"themes":{"ZambiaThemes.private":[4293718263,4289012262,0.03,0.04]},"specs":[["zm.private","ZambiaCountry.zambia",520,110,[["latin.upper",[58.25,4.75,138.25,105],3,3,0,null,"prefix"],["latin.digits",[226.75,4.75,180.5,105],4,4,0,null,"serial"],["latin.upper",[440.5,4.75,39.5,105],1,1,0,null,"suffix"]]]],"resolvers":{},"assets":[],"gallery":[["zm.private","Private","zm.private",["ADD","4077","T"],"Zambia","Private",null,"ZambiaThemes.private","ZambiaCountry.zambia","ZambiaValidator"]]}''', {}, {'ZambiaValidator': ZambiaValidator})
