// Compiles a dart2wasm-generated main module from `source` which can then
// be instantiated via the `instantiate` method.
//
// `source` needs to be a `Response` object (or promise thereof) e.g. created
// via the `fetch()` JS API.
export async function compileStreaming(source) {
  const builtins = {builtins: ['js-string']};
  return new CompiledApp(
      await WebAssembly.compileStreaming(source, builtins), builtins);
}

// Compiles a dart2wasm-generated wasm module from `bytes` which is then
// instantiable via the `instantiate` method.
export async function compile(bytes) {
  const builtins = {builtins: ['js-string']};
  return new CompiledApp(await WebAssembly.compile(bytes, builtins), builtins);
}

class CompiledApp {
  constructor(module, builtins) {
    this.module = module;
    this.builtins = builtins;
  }

  // The second argument is an options object containing:
  // `loadDeferredModules` is a JS function that takes an array of module names
  //   matching wasm files produced by the dart2wasm compiler. It also takes a
  //   callback that should be invoked for each loaded module with 2 arguments:
  //   (1) the module name, (2) the loaded module in a format supported by
  //   `WebAssembly.compile` or `WebAssembly.compileStreaming`. The callback
  //   returns a Promise that resolves when the module is instantiated.
  //   loadDeferredModules should return a Promise that resolves when all the
  //   modules have been loaded and the callback promises have resolved.
  // `loadDeferredId` is a JS function that takes load ID produced by the
  //   compiler when the `use-load-ids` option is passed. Each load ID maps to
  //   one or more wasm files as specified in the emitted JSON file. It also
  //   takes a callback that should be invoked for each loaded module with 2
  //   arguments: (1) the module name, (2) the loaded module in a format
  //   supported by `WebAssembly.compile` or `WebAssembly.compileStreaming`.
  //   The callback returns a Promise that resolves when the module is
  //   instantiated.
  //   loadDeferredId should return a Promise that resolves when all the
  //   modules have been loaded and the callback promises have resolved.
  async instantiate(additionalImports, {loadDeferredModules, loadDeferredId} = {}) {
    let dartInstance;

    // Prints to the console
    function printToConsole(value) {
      if (typeof dartPrint == "function") {
        dartPrint(value);
        return;
      }
      if (typeof console == "object" && typeof console.log != "undefined") {
        console.log(value);
        return;
      }
      if (typeof print == "function") {
        print(value);
        return;
      }

      throw "Unable to print message: " + value;
    }

    // A special symbol attached to functions that wrap Dart functions.
    const jsWrappedDartFunctionSymbol = Symbol("JSWrappedDartFunction");

    function finalizeWrapper(dartFunction, wrapped) {
      wrapped.dartFunction = dartFunction;
      wrapped[jsWrappedDartFunctionSymbol] = true;
      return wrapped;
    }

    // Imports
    const dart2wasm = {
            AB: (decoder, codeUnits) => decoder.decode(codeUnits),
      AC: Function.prototype.call.bind(Object.getOwnPropertyDescriptor(DataView.prototype, 'byteLength').get),
      AD: (o, i) => o[i],
      AE: s => {
        if (!/^\s*[+-]?(?:Infinity|NaN|(?:\.\d+|\d+(?:\.\d*)?)(?:[eE][+-]?\d+)?)\s*$/.test(s)) {
          return NaN;
        }
        return parseFloat(s);
      },
      AF: (x0,x1) => { x0.method = x1 },
      AG: x0 => x0.changedTouches,
      AH: x0 => x0.innerHeight,
      AI: () => globalThis.WeakRef,
      AJ: (x0,x1) => { x0.height = x1 },
      B: s => printToConsole(s),
      BB: (o, start, length) => new Uint8Array(o.buffer, o.byteOffset + start, length),
      BC: Function.prototype.call.bind(DataView.prototype.setFloat64),
      BD: o => o.length,
      BE: (x0,x1) => x0.removeProperty(x1),
      BF: (x0,x1) => { x0.noValidate = x1 },
      BG: x0 => x0.offsetY,
      BH: x0 => x0.height,
      BI: (a, i) => a.splice(i, 1),
      BJ: (x0,x1) => { x0.width = x1 },
      C: Function.prototype.call.bind(Number.prototype.toString),
      CB: () => new TextDecoder("utf-8", {fatal: true}),
      CC: o => o.byteOffset,
      CD: o => {
        if (o === undefined) return 1;
        var type = typeof o;
        if (type === 'boolean') return 2;
        if (type === 'number') return 3;
        if (type === 'string') return 4;
        if (o instanceof Array) return 5;
        if (ArrayBuffer.isView(o)) {
          if (o instanceof Int8Array) return 6;
          if (o instanceof Uint8Array) return 7;
          if (o instanceof Uint8ClampedArray) return 8;
          if (o instanceof Int16Array) return 9;
          if (o instanceof Uint16Array) return 10;
          if (o instanceof Int32Array) return 11;
          if (o instanceof Uint32Array) return 12;
          if (o instanceof Float32Array) return 13;
          if (o instanceof Float64Array) return 14;
          if (o instanceof DataView) return 15;
        }
        if (o instanceof ArrayBuffer) return 16;
        // Feature check for `SharedArrayBuffer` before doing a type-check.
        if (globalThis.SharedArrayBuffer !== undefined &&
            o instanceof SharedArrayBuffer) {
            return 17;
        }
        if (o instanceof Promise) return 18;
        return 19;
      },
      CE: (x0,x1) => x0.appendChild(x1),
      CF: (x0,x1) => x0.removeAttribute(x1),
      CG: x0 => x0.offsetX,
      CH: x0 => x0.clientHeight,
      CI: a => a.pop(),
      CJ: x0 => x0.height,
      D: Function.prototype.call.bind(BigInt.prototype.toString),
      DB: () => new TextDecoder("utf-8", {fatal: false}),
      DC: o => o.buffer,
      DD: x0 => x0.state,
      DE: x0 => x0.debugShowSemanticsNodes,
      DF: x0 => x0.isConnected,
      DG: x0 => x0.type,
      DH: x0 => x0.innerWidth,
      DI: (x0,x1,x2) => x0.insertBefore(x1,x2),
      DJ: x0 => x0.width,
      E: (exn) => {
        let stackString = exn.toString();
        let frames = stackString.split('\n');
        let drop = 4;
        if (frames[0].startsWith('Error')) {
            drop += 1;
        }
        return frames.slice(drop).join('\n');
      },
      EB: s => s.trimLeft(),
      EC: (b, o) => new DataView(b, o),
      ED: x0 => x0.hash,
      EE: (o, c) => o instanceof c,
      EF: x0 => x0.click(),
      EG: x0 => x0.hasFocus(),
      EH: x0 => x0.width,
      EI: x0 => x0.id,
      EJ: x0 => x0.rasterEndMilliseconds,
      F: () => new Error().stack,
      FB: (l, r) => l === r,
      FC: (b, o, l) => new DataView(b, o, l),
      FD: (x0,x1,x2) => x0.removeEventListener(x1,x2),
      FE: x0 => x0.vendor,
      FF: (x0,x1) => x0.getElementsByClassName(x1),
      FG: x0 => x0.shiftKey,
      FH: x0 => x0.clientWidth,
      FI: x0 => x0.offsetHeight,
      FJ: x0 => x0.rasterStartMilliseconds,
      G: s => JSON.stringify(s),
      GB: s => s.toUpperCase(),
      GC: Function.prototype.call.bind(DataView.prototype.getUint8),
      GD: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      GE: (x0,x1) => x0.createTextNode(x1),
      GF: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmF32ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      GG: x0 => x0.visibilityState,
      GH: (x0,x1) => x0.removeChild(x1),
      GI: x0 => x0.offsetWidth,
      GJ: x0 => x0.imageBitmaps,
      H: Function.prototype.call.bind(Number.prototype.toString),
      HB: Object.is,
      HC: Function.prototype.call.bind(DataView.prototype.setUint8),
      HD: x0 => x0.state,
      HE: (x0,x1) => { x0.nonce = x1 },
      HF: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmF64ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      HG: x0 => x0.disconnect(),
      HH: x0 => x0.firstChild,
      HI: x0 => x0.stopPropagation(),
      HJ: x0 => x0.canvasKitMaximumSurfaces,
      I: Function.prototype.call.bind(String.prototype.indexOf),
      IB: (x0,x1) => x0.test(x1),
      IC: Function.prototype.call.bind(DataView.prototype.getFloat64),
      ID: (x0,x1,x2) => x0.addEventListener(x1,x2),
      IE: x0 => x0.nonce,
      IF: (x0,x1) => x0.contains(x1),
      IG: x0 => new Intl.Locale(x0),
      IH: x0 => x0.viewConstraints,
      II: x0 => x0.disabled,
      IJ: x0 => x0.hostElement,
      J: (s, p, i) => s.lastIndexOf(p, i),
      JB: (a, i, v) => a[i] = v,
      JC: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Float64Array) return 1;
        return 2;
      },
      JD: (x0,x1) => x0.go(x1),
      JE: () => globalThis.window.flutterConfiguration,
      JF: (s) => +s,
      JG: x0 => x0.region,
      JH: x0 => x0.hostElement,
      JI: (x0,x1) => { x0.min = x1 },
      JJ: x0 => x0.location,
      K: (exn) => {
        if (exn instanceof Error) {
          return exn.stack;
        } else {
          return null;
        }
      },
      KB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmI8ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      KC: (t, s) => t.set(s),
      KD: (x0,x1) => x0.append(x1),
      KE: (x0,x1) => x0.attachShadow(x1),
      KF: x0 => x0.target,
      KG: x0 => x0.script,
      KH: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      KI: (x0,x1) => { x0.max = x1 },
      KJ: (x0,x1) => x0.getModifierState(x1),
      L: o => o === undefined,
      LB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmI16ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      LC: Function.prototype.call.bind(DataView.prototype.setFloat32),
      LD: (x0,x1) => { x0.textContent = x1 },
      LE: x0 => x0.preventDefault(),
      LF: (x0,x1) => x0.dispatchEvent(x1),
      LG: x0 => x0.language,
      LH: x0 => ({runApp: x0}),
      LI: (x0,x1) => { x0.disabled = x1 },
      LJ: x0 => x0.metaKey,
      M: o => String(o),
      MB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmI32ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      MC: Function.prototype.call.bind(DataView.prototype.getFloat32),
      MD: (ms, c) =>
      setTimeout(() => dartInstance.exports.$invokeCallback(c),ms),
      ME: (x0,x1) => x0.contains(x1),
      MF: (x0,x1) => x0.createEvent(x1),
      MG: x0 => x0.languages,
      MH: Function.prototype.call.bind(DataView.prototype.setBigInt64),
      MI: (x0,x1) => { x0.scrollLeft = x1 },
      MJ: x0 => x0.altKey,
      N: (c) =>
      queueMicrotask(() => dartInstance.exports.$invokeCallback(c)),
      NB: Function.prototype.call.bind(String.prototype.toLowerCase),
      NC: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Float32Array) return 1;
        return 2;
      },
      ND: x0 => x0.parentElement,
      NE: (x0,x1) => x0.focus(x1),
      NF: (x0,x1,x2,x3) => x0.initEvent(x1,x2,x3),
      NG: (x0,x1) => x0.observe(x1),
      NH: Function.prototype.call.bind(DataView.prototype.getBigInt64),
      NI: (x0,x1) => { x0.spellcheck = x1 },
      NJ: x0 => x0.ctrlKey,
      O: (x0,x1) => x0.didCreateEngineInitializer(x1),
      OB: (o, p, r) => o.replace(p, () => r),
      OC: Function.prototype.call.bind(DataView.prototype.getUint32),
      OD: (x0,x1) => x0.querySelectorAll(x1),
      OE: (x0,x1) => x0.closest(x1),
      OF: () => globalThis.window,
      OG: (wasmFunction,f) => finalizeWrapper(f, function(x0,x1) { return wasmFunction(f,arguments.length,x0,x1) }),
      OH: (o, start, length) => new BigInt64Array(o.buffer, o.byteOffset + start, length),
      OI: (x0,x1) => { x0.disabled = x1 },
      OJ: x0 => x0.isComposing,
      P: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      PB: (o, p, r) => o.replaceAll(p, () => r),
      PC: Function.prototype.call.bind(DataView.prototype.setUint32),
      PD: x0 => x0.length,
      PE: (x0,x1) => x0.getAttribute(x1),
      PF: x0 => x0.readText(),
      PG: x0 => new ResizeObserver(x0),
      PH: () => typeof dartUseDateNowForTicks !== "undefined",
      PI: (map, o, v) => map.set(o, v),
      PJ: x0 => x0.code,
      Q: (wasmFunction,f) => finalizeWrapper(f, function() { return wasmFunction(f,arguments.length) }),
      QB: (x0,x1) => x0[x1],
      QC: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Uint32Array) return 1;
        return 2;
      },
      QD: (x0,x1) => x0.item(x1),
      QE: x0 => x0.activeElement,
      QF: x0 => x0.clipboard,
      QG: x0 => globalThis.parseFloat(x0),
      QH: () => Date.now(),
      QI: (x0,x1,x2) => x0.setItem(x1,x2),
      QJ: x0 => x0.repeat,
      R: (x0,x1) => ({initializeEngine: x0,autoStart: x1}),
      RB: x0 => x0.index,
      RC: Function.prototype.call.bind(DataView.prototype.getInt32),
      RD: x0 => x0.userAgent,
      RE: (x0,x1) => x0.add(x1),
      RF: (x0,x1) => x0.writeText(x1),
      RG: (x0,x1) => x0.getComputedStyle(x1),
      RH: () => 1000 * performance.now(),
      RI: x0 => x0.localStorage,
      RJ: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      S: (wasmFunction,f) => finalizeWrapper(f, function(x0,x1) { return wasmFunction(f,arguments.length,x0,x1) }),
      SB: x0 => x0.pop(),
      SC: Function.prototype.call.bind(DataView.prototype.setInt32),
      SD: x0 => x0.maxTouchPoints,
      SE: x0 => x0.classList,
      SF: x0 => x0.unlock(),
      SG: x0 => x0.documentElement,
      SH: x0 => new Uint8Array(x0),
      SI: () => globalThis.window,
      SJ: x0 => x0.userAgent,
      T: x0 => new Promise(x0),
      TB: x0 => x0.flags,
      TC: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Int32Array) return 1;
        return 2;
      },
      TD: x0 => x0.platform,
      TE: x0 => x0.data,
      TF: (x0,x1) => x0.lock(x1),
      TG: x0 => x0.computedStyleMap(),
      TH: (x0,x1,x2) => x0.slice(x1,x2),
      TI: (x0,x1) => x0.revokeObjectURL(x1),
      TJ: x0 => x0.navigator,
      U: (x0,x1,x2) => x0.call(x1,x2),
      UB: s => s.trim(),
      UC: o => o instanceof Uint16Array,
      UD: x0 => x0.navigator,
      UE: x0 => x0.scrollTop,
      UF: x0 => x0.orientation,
      UG: (x0,x1) => x0.get(x1),
      UH: (x0,x1) => x0.decode(x1),
      UI: (x0,x1) => { x0.src = x1 },
      UJ: (x0,x1,x2,x3) => x0.open(x1,x2,x3),
      V: (constructor, args) => {
        const factoryFunction = constructor.bind.apply(
            constructor, [null, ...args]);
        return new factoryFunction();
      },
      VB: (a, s) => a.join(s),
      VC: Function.prototype.call.bind(DataView.prototype.getUint16),
      VD: s => new Date(s * 1000).getTimezoneOffset() * 60,
      VE: (handle) => clearTimeout(handle),
      VF: (x0,x1) => x0.querySelector(x1),
      VG: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      VH: (x0,x1) => x0.adoptText(x1),
      VI: (x0,x1,x2,x3,x4) => globalThis.createImageBitmap(x0,x1,x2,x3,x4),
      VJ: x0 => x0.length,
      W: x0 => new Array(x0),
      WB: x0 => x0.random(),
      WC: Function.prototype.call.bind(DataView.prototype.setUint16),
      WD: Date.now,
      WE: (x0,x1) => { x0.scrollTop = x1 },
      WF: (x0,x1) => { x0.content = x1 },
      WG: x0 => x0.matches,
      WH: x0 => x0.first(),
      WI: x0 => x0.naturalHeight,
      WJ: x0 => x0.getReader(),
      X: o => [o],
      XB: () => globalThis.Math,
      XC: o => o instanceof Int16Array,
      XD: (x0,x1,x2) => x0.setAttribute(x1,x2),
      XE: x0 => x0.tagName,
      XF: x0 => x0.head,
      XG: (x0,x1) => x0.matchMedia(x1),
      XH: x0 => x0.next(),
      XI: x0 => x0.naturalWidth,
      XJ: x0 => x0.value,
      Y: (o0, o1) => [o0, o1],
      YB: (x0,x1) => x0.error(x1),
      YC: Function.prototype.call.bind(DataView.prototype.getInt16),
      YD: (x0,x1,x2,x3) => x0.setProperty(x1,x2,x3),
      YE: (x0,x1,x2) => x0.setSelectionRange(x1,x2),
      YF: (x0,x1) => { x0.name = x1 },
      YG: x0 => x0.matches,
      YH: x0 => x0.current(),
      YI: x0 => x0.decode(),
      YJ: x0 => x0.done,
      Z: (o0, o1, o2) => [o0, o1, o2],
      ZB: () => globalThis.console,
      ZC: Function.prototype.call.bind(DataView.prototype.setInt16),
      ZD: x0 => x0.style,
      ZE: (x0,x1) => { x0.value = x1 },
      ZF: (x0,x1) => { x0.title = x1 },
      ZG: x0 => x0.timeStamp,
      ZH: (x0,x1) => new Intl.v8BreakIterator(x0,x1),
      ZI: (x0,x1) => { x0.decoding = x1 },
      ZJ: x0 => x0.read(),
      a: (o0, o1, o2, o3) => [o0, o1, o2, o3],
      aB: s => s.trimRight(),
      aC: o => o instanceof Uint8ClampedArray,
      aD: (x0,x1) => x0.createElement(x1),
      aE: (x0,x1,x2) => x0.setSelectionRange(x1,x2),
      aF: () => globalThis.document,
      aG: (x0,x1) => x0.hasAttribute(x1),
      aH: x0 => x0.v8BreakIterator,
      aI: (x0,x1) => { x0.crossOrigin = x1 },
      aJ: x0 => x0.body,
      b: (x0,x1,x2) => { x0[x1] = x2 },
      bB: (a, i) => a.push(i),
      bC: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Uint8Array) return 1;
        return 2;
      },
      bD: x0 => x0.body,
      bE: (x0,x1) => { x0.value = x1 },
      bF: (x0,x1) => x0.vibrate(x1),
      bG: x0 => x0.buttons,
      bH: () => globalThis.Intl,
      bI: (x0,x1) => x0.createObjectURL(x1),
      bJ: (x0,x1) => new OffscreenCanvas(x0,x1),
      c: o => o,
      cB: (x0,x1,x2,x3) => x0.pushState(x1,x2,x3),
      cC: Function.prototype.call.bind(DataView.prototype.setInt8),
      cD: x0 => x0.remove(),
      cE: x0 => x0.relatedTarget,
      cF: (o, p) => p in o,
      cG: x0 => x0.ctrlKey,
      cH: (x0,x1) => x0.segment(x1),
      cI: x0 => x0.URL,
      cJ: x0 => x0.assetBase,
      d: (o, p) => o[p],
      dB: () => ({}),
      dC: Function.prototype.call.bind(DataView.prototype.getInt8),
      dD: (x0,x1) => x0.getPropertyValue(x1),
      dE: s => {
        if (/[[\]{}()*+?.\\^$|]/.test(s)) {
            s = s.replace(/[[\]{}()*+?.\\^$|]/g, '\\$&');
        }
        return s;
      },
      dF: x0 => x0.arrayBuffer(),
      dG: x0 => x0.y,
      dH: x0 => x0.index,
      dI: x0 => new Blob(x0),
      dJ: x0 => x0.loader,
      e: () => globalThis,
      eB: (o, p, v) => o[p] = v,
      eC: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Int8Array) return 1;
        return 2;
      },
      eD: (x0,x1) => x0.warn(x1),
      eE: x0 => x0.value,
      eF: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof ArrayBuffer) return 1;
        if (globalThis.SharedArrayBuffer !== undefined &&
            o instanceof SharedArrayBuffer) {
          return 2;
        }
        return 3;
      },
      eG: x0 => x0.x,
      eH: x0 => x0.next(),
      eI: (x0,x1,x2,x3,x4) => ({type: x0,data: x1,premultiplyAlpha: x2,colorSpaceConversion: x3,preferAnimation: x4}),
      eJ: () => globalThis._flutter,
      f: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      fB: () => [],
      fC: (o, start, length) => new Float64Array(o.buffer, o.byteOffset + start, length),
      fD: x0 => x0.console,
      fE: x0 => x0.selectionDirection,
      fF: x0 => x0.status,
      fG: x0 => x0.offsetTop,
      fH: x0 => x0.value,
      fI: x0 => new window.ImageDecoder(x0),
      g: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      gB: b => !!b,
      gC: (o, start, length) => new Float32Array(o.buffer, o.byteOffset + start, length),
      gD: (x0,x1) => { x0.id = x1 },
      gE: x0 => x0.selectionStart,
      gF: (x0,x1) => x0.fetch(x1),
      gG: x0 => x0.scrollLeft,
      gH: x0 => x0.done,
      gI: x0 => x0.name,
      h: (x0,x1) => ({addView: x0,removeView: x1}),
      hB: x0 => new Int8Array(x0),
      hC: (o, start, length) => new Uint32Array(o.buffer, o.byteOffset + start, length),
      hD: (x0,x1) => x0.requestAnimationFrame(x1),
      hE: x0 => x0.selectionEnd,
      hF: x0 => x0.content,
      hG: x0 => x0.offsetLeft,
      hH: (o, m, a) => o[m].apply(o, a),
      hI: x0 => x0.repetitionCount,
      i: (x0,x1) => x0.exec(x1),
      iB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmI8ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      iC: (o, start, length) => new Int32Array(o.buffer, o.byteOffset + start, length),
      iD: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      iE: x0 => x0.value,
      iF: x0 => x0.document,
      iG: x0 => x0.offsetParent,
      iH: x0 => x0.iterator,
      iI: x0 => x0.frameCount,
      j: x0 => x0.length,
      jB: x0 => new Uint8Array(x0),
      jC: (o, start, length) => new Uint16Array(o.buffer, o.byteOffset + start, length),
      jD: x0 => x0.now(),
      jE: x0 => x0.selectionDirection,
      jF: x0 => x0.language,
      jG: x0 => x0.deltaMode,
      jH: () => globalThis.Symbol,
      jI: x0 => x0.selectedTrack,
      k: o => o,
      kB: x0 => new Uint8ClampedArray(x0),
      kC: (o, start, length) => new Int16Array(o.buffer, o.byteOffset + start, length),
      kD: x0 => x0.performance,
      kE: x0 => x0.selectionStart,
      kF: (x0,x1,x2,x3) => x0.register(x1,x2,x3),
      kG: x0 => x0.deltaY,
      kH: (x0,x1) => new Intl.Segmenter(x0,x1),
      kI: x0 => x0.completed,
      l: o => {
        if (o === undefined || o === null) return 0;
        if (typeof o === 'number') return 1;
        return 2;
      },
      lB: x0 => new Int16Array(x0),
      lC: (o, start, length) => new Uint8ClampedArray(o.buffer, o.byteOffset + start, length),
      lD: (x0,x1) => x0.unregister(x1),
      lE: x0 => x0.selectionEnd,
      lF: (x0,x1) => x0.prepend(x1),
      lG: x0 => x0.deltaX,
      lH: x0 => x0.Segmenter,
      lI: x0 => x0.ready,
      m: (x0,x1) => { x0.lastIndex = x1 },
      mB: x0 => new Uint16Array(x0),
      mC: (o, start, length) => new Int8Array(o.buffer, o.byteOffset + start, length),
      mD: () => globalThis.window.FinalizationRegistry,
      mE: x0 => x0.keyCode,
      mF: (x0,x1,x2,x3) => x0.addEventListener(x1,x2,x3),
      mG: x0 => x0.wheelDeltaY,
      mH: x0 => x0.buffer,
      mI: x0 => x0.tracks,
      n: (s, m) => {
        try {
          return new RegExp(s, m);
        } catch (e) {
          return String(e);
        }
      },
      nB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmI16ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      nC: x0 => x0.history,
      nD: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      nE: (x0,x1) => x0.scrollIntoView(x1),
      nF: (x0,x1) => x0.querySelector(x1),
      nG: x0 => x0.wheelDeltaX,
      nH: x0 => x0.wasmMemory,
      nI: x0 => x0.close(),
      o: o => o instanceof RegExp,
      oB: x0 => new Int32Array(x0),
      oC: x0 => x0.search,
      oD: x0 => new window.FinalizationRegistry(x0),
      oE: x0 => x0.multiViewEnabled,
      oF: (x0,x1) => x0.querySelectorAll(x1),
      oG: x0 => x0.key,
      oH: () => globalThis.window._flutter_skwasmInstance,
      oI: (x0,x1) => ({frameIndex: x0,completeFramesOnly: x1}),
      p: o => o,
      pB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmI32ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      pC: o => {
        if (o === null || o === undefined) return 0;
        if (typeof(o) === 'string') return 1;
        return 2;
      },
      pD: x0 => x0.scale,
      pE: x0 => x0.parent,
      pF: x0 => x0.tabIndex,
      pG: x0 => x0.identifier,
      pH: () => new TextDecoder(),
      pI: (x0,x1) => x0.decode(x1),
      q: o => {
        if (o === undefined || o === null) return 0;
        if (typeof o === 'boolean') return 1;
        return 2;
      },
      qB: x0 => new Uint32Array(x0),
      qC: x0 => x0.location,
      qD: x0 => x0.visualViewport,
      qE: (x0,x1) => x0.replaceWith(x1),
      qF: x0 => x0.parentNode,
      qG: x0 => x0.touches,
      qH: x0 => x0.debugSkipFontRetryDelay,
      qI: x0 => x0.displayHeight,
      r: x0 => x0.dotAll,
      rB: x0 => new Float32Array(x0),
      rC: x0 => x0.pathname,
      rD: x0 => x0.devicePixelRatio,
      rE: (x0,x1) => { x0.type = x1 },
      rF: x0 => x0.clientY,
      rG: x0 => x0.pressure,
      rH: (x0,x1,x2) => x0.set(x1,x2),
      rI: x0 => x0.displayWidth,
      s: x0 => x0.unicode,
      sB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmF32ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      sC: (x0,x1,x2,x3) => x0.replaceState(x1,x2,x3),
      sD: (d, digits) => d.toFixed(digits),
      sE: (x0,x1) => { x0.className = x1 },
      sF: x0 => x0.clientX,
      sG: x0 => x0.tiltY,
      sH: x0 => x0.fontFallbackBaseUrl,
      sI: x0 => x0.duration,
      t: x0 => x0.ignoreCase,
      tB: x0 => new Float64Array(x0),
      tC: o => {
        const proto = Object.getPrototypeOf(o);
        return proto === Object.prototype || proto === null;
      },
      tD: x0 => x0.maxHeight,
      tE: (x0,x1) => { x0.tabIndex = x1 },
      tF: x0 => x0.getBoundingClientRect(),
      tG: x0 => x0.tiltX,
      tH: (handle) => clearInterval(handle),
      tI: x0 => x0.image,
      u: x0 => x0.multiline,
      uB: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmF64ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      uC: o => Object.keys(o),
      uD: x0 => x0.maxWidth,
      uE: (x0,x1) => { x0.name = x1 },
      uF: x0 => x0.bottom,
      uG: x0 => x0.pointerType,
      uH: (ms, c) =>
      setInterval(() => dartInstance.exports.$invokeCallback(c), ms),
      uI: () => globalThis.window.ImageDecoder,
      v: (string, token) => string.split(token),
      vB: x0 => new ArrayBuffer(x0),
      vC: o => typeof o === 'function' && o[jsWrappedDartFunctionSymbol] === true,
      vD: x0 => x0.minHeight,
      vE: (x0,x1) => { x0.placeholder = x1 },
      vF: x0 => x0.top,
      vG: x0 => x0.pointerId,
      vH: () => Date.now(),
      vI: (o, p) => p in o,
      w: o => o instanceof Array,
      wB: (x0,x1,x2) => new Uint8Array(x0,x1,x2),
      wC: f => f.dartFunction,
      wD: x0 => x0.minWidth,
      wE: (x0,x1) => { x0.autocomplete = x1 },
      wF: x0 => x0.right,
      wG: x0 => x0.getCoalescedEvents(),
      wH: (map, o) => map.get(o),
      wI: x0 => x0.groups,
      x: (a, i) => a[i],
      xB: (x0,x1,x2) => new DataView(x0,x1,x2),
      xC: (wasmFunction,f) => finalizeWrapper(f, function(x0) { return wasmFunction(f,arguments.length,x0) }),
      xD: x0 => x0.height,
      xE: (x0,x1) => { x0.name = x1 },
      xF: x0 => x0.left,
      xG: (x0,x1) => x0.getModifierState(x1),
      xH: () => new WeakMap(),
      xI: (x0,x1) => x0.getItem(x1),
      y: a => a.length,
      yB: (o, p) => o[p],
      yC: (wasmFunction,f) => finalizeWrapper(f, function(x0,x1) { return wasmFunction(f,arguments.length,x0,x1) }),
      yD: x0 => x0.width,
      yE: (x0,x1) => { x0.placeholder = x1 },
      yF: x0 => x0.clientY,
      yG: x0 => x0.blur(),
      yH: x0 => new WeakRef(x0),
      yI: (x0,x1) => x0.transferFromImageBitmap(x1),
      z: (string, times) => string.repeat(times),
      zB: (o) => new DataView(o.buffer, o.byteOffset, o.byteLength),
      zC: (p, s, f) => p.then(s, (e) => f(e, e === undefined)),
      zD: x0 => x0.screen,
      zE: (x0,x1) => { x0.action = x1 },
      zF: x0 => x0.clientX,
      zG: x0 => x0.button,
      zH: x0 => x0.deref(),
      zI: (x0,x1) => x0.getContext(x1),

    };

    const baseImports = {
      _: dart2wasm,
      Math: Math,
      Date: Date,
      Object: Object,
      Array: Array,
      Reflect: Reflect,
      WebAssembly: {
        JSTag: WebAssembly.JSTag,
      },
      "": new Proxy({}, { get(_, prop) { return prop; } }),

    };

    const jsStringPolyfill = {
      "charCodeAt": (s, i) => s.charCodeAt(i),
      "compare": (s1, s2) => {
        if (s1 < s2) return -1;
        if (s1 > s2) return 1;
        return 0;
      },
      "concat": (s1, s2) => s1 + s2,
      "equals": (s1, s2) => s1 === s2,
      "fromCharCode": (i) => String.fromCharCode(i),
      "length": (s) => s.length,
      "substring": (s, a, b) => s.substring(a, b),
      "fromCharCodeArray": (a, start, end) => {
        if (end <= start) return '';

        const read = dartInstance.exports.$wasmI16ArrayGet;
        let result = '';
        let index = start;
        const chunkLength = Math.min(end - index, 500);
        let array = new Array(chunkLength);
        while (index < end) {
          const newChunkLength = Math.min(end - index, 500);
          for (let i = 0; i < newChunkLength; i++) {
            array[i] = read(a, index++);
          }
          if (newChunkLength < chunkLength) {
            array = array.slice(0, newChunkLength);
          }
          result += String.fromCharCode(...array);
        }
        return result;
      },
      "intoCharCodeArray": (s, a, start) => {
        if (s === '') return 0;

        const write = dartInstance.exports.$wasmI16ArraySet;
        for (var i = 0; i < s.length; ++i) {
          write(a, start++, s.charCodeAt(i));
        }
        return s.length;
      },
      "test": (s) => typeof s == "string",
    };


    

    dartInstance = await WebAssembly.instantiate(this.module, {
      ...baseImports,
      ...additionalImports,
      
      "wasm:js-string": jsStringPolyfill,
    });

    return new InstantiatedApp(this, dartInstance);
  }
}

class InstantiatedApp {
  constructor(compiledApp, instantiatedModule) {
    this.compiledApp = compiledApp;
    this.instantiatedModule = instantiatedModule;
  }

  // Call the main function with the given arguments.
  invokeMain(...args) {
    this.instantiatedModule.exports.$invokeMain(args);
  }
}
